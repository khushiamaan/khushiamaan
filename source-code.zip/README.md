# Amaan ki Khushi / Khushi Forever
Invite-only couple memory website, with an Android browser-based launcher named Khushi Forever. Approved burgundy, blush and rose-gold visual design. User-provided couple portrait is the Android icon.

## Features
- Durable shared photo/video/audio memories in D1 + R2, edit/delete, dates and captions.
- Site-managed ChatGPT sign-in and invitation access. No separate private section.
- OWNER_EMAIL runtime secret identifies original owner; at most one invited partner email may receive in-app editing privileges. Guests can view and react, not upload or edit. Platform invitations are managed separately in Site Share settings.
- Story milestones, shared love notes, wish constellation, personal mood preference, surprise memory, original synthesised melody or uploaded music.
- Local photo canvas editor: filters, rotate, centre crop, frames, captions, two-photo collage, PNG export.
- IMG.LY browser AI background removal, on-demand model download; no paid API.
- Video trim/export with audio through MediaRecorder, up to 60 seconds in supported browsers, exported as WebM. No generative AI video editing.
- Installable PWA and a signed development Android APK opening the same online app in a browser Custom Tab. No offline media caching.

## Live calls
Owner and invited partner can make one-to-one audio/video calls through WebRTC in the website and the Khushi Forever Android browser launcher. Microphone/camera permissions are requested only when starting/answering. Includes incoming call panel, answer/decline, audio-only answer, mic mute, camera toggle and hangup. Both apps must remain open. No background push ringing or recording. Signalling is authenticated, owner-only and expires; ended calls clear SDP. Public Cloudflare STUN supports direct connectivity; no TURN relay is configured, so separate mobile networks/firewalls can prevent calls. Two-phone end-to-end call verification is pending; signalling lifecycle is integration-tested.

## Setup
Use Node 22.13+, `pnpm install`, configure `.openai/hosting.json` with DB and BUCKET, and set runtime OWNER_EMAIL to the verified Site owner's email. Never place owner configuration or signing keys in source. Starter preview and build instructions are in the Sites skill. Generate/apply the included schema migration. Original photographs are supplied privately and are deliberately excluded from the downloadable source package.

## Validation
`node node_modules/typescript/bin/tsc --noEmit`
`node tests/integration.mjs` tests actual API modules in isolated Miniflare D1/R2 with simulated trusted dispatch identity; it never changes production or starts a preview server.
`npm run build`
Browser QA: homepage, navigation, photo filters/caption/frame, actual AI background removal and trimmed video export with VP8 video + Opus audio. Android APK signature, manifest, icon and DEX verified; physical Android installation not tested here.

## Boundaries
Each file is capped at 50 MB. No unlimited storage promise. Notes with dates are visible immediately to invited guests; dates are descriptive labels, not secret time locks. Backup exports metadata and file links, not original media bytes. Website-sharing invitations must be configured through native Site sharing; copying a URL does not grant access. In-app partner editing permission alone does not invite a person to the Site.

## Source and credits
Application code is offered under AGPL-3.0; see LICENSE.md. Background removal uses @imgly/background-removal 1.7.0 (AGPL-3.0). ONNX Runtime Web, React, Vinext and Lucide retain their respective licences. Visit `/source` for the downloadable corresponding app source and library source link.

## Android notification test build (1.1)
The Android project now uses Gradle, the supplied Firebase client configuration, and Firebase Messaging 26.0.1. It requests Android notification permission, receives high-priority incoming-call data messages, expires stale notifications and opens the secure website for answering. FCM tokens are linked to a signed-in owner account through a URL fragment and an explicit website confirmation; tokens are not returned by list endpoints. The server can send FCM HTTP v1 messages when FIREBASE_SERVICE_ACCOUNT_JSON is set as a runtime secret. No service account key is present in source or the APK.

This is a notification test build, not a completed native background calling app. The microphone and WebRTC media remain owned by Chrome. Screen-off / app-closed call continuity and notification delivery must be tested on the two real Android phones. Native foreground-service audio is not implemented. Without the Firebase server secret, no automatic incoming-call push is sent. A linked phone and granted notification permission are also required. Android Force Stop prevents delivery until reopening.

Build Android using JDK 17, Gradle 8.9, platform 35, and the signing key recovered from the private signing backup. Keep local.properties, tool downloads, Gradle caches and signing keys untracked. Run Gradle assembleDebug from android/. The application package remains com.amaankikhushi.app, app label Khushi Forever, and the launcher icon remains the supplied couple portrait.

### Android 1.2 earpiece test mode

The optional “App ke andar call” button opens an isolated Android WebView using the existing Site login. Its cookie jar is separate from Chrome; email sign-in may be necessary because identity providers can refuse embedded browsers. Browser mode remains available. This is a hybrid WebRTC call, not a standalone native WebRTC engine.

An AndroidX WebMessage listener exposes `prepare/route/end` only to the exact production Site origin and only the main frame. Microphone/camera grants are restricted to that origin and to the requested, known resources. No account passwords, Site access bypass tokens, or Firebase service credentials are embedded in the APK. Navigation away from the Site ends active media service. TLS errors are never overridden.

For an explicitly started or accepted call, the Activity requests Android mic/camera permission, starts a microphone (and video camera where needed) foreground service while visible, then permits WebRTC capture. Voice communication mode and Android communication-device APIs request earpiece for audio, speaker for video; top toolbar buttons request either route and report failures. An ongoing notification includes End call. Audio focus/mode and partial wake lock are released on hangup, Activity destruction, service teardown, and task removal. The existing FCM call notification opens this mode only after a call has successfully prepared in it.

Device checks still required: embedded sign-in on both phones; actual route switching on each Android version; mic indicator/service cleanup; outgoing/incoming call while app backgrounded; screen-off voice continuity; interruption by a cellular call. A foreground service does not guarantee WebView timers/network survival on every manufacturer. Force-stop is unsupported for delivery. Camera/background call behavior and universal earpiece compatibility are not asserted as verified. STUN-only transport still has no TURN relay.

### Android 1.3 background audio investigation

A phone test confirmed earpiece output in 1.2, but locking the phone caused delayed outgoing audio and silent incoming audio. Background voice continuity is **not** verified. Version 1.3 separates incoming audio into a persistent `<audio>` element outside the minimisable call panel; muted video is only a visual sink. This also fixes voice stopping when the call panel is closed.

Once WebRTC connects, the native foreground service receives only the current call UUID and the existing authenticated WebView cookie in memory. A native scheduled heartbeat POSTs to the fixed HTTPS Site endpoint every 8 seconds, independently of WebView JavaScript timers. Redirects are disabled; credentials never go to another origin, storage, logs, or a browser bundle. The server retains its usual Site identity, membership, session-id and expiry checks. Auth loss, ended calls, and teardown stop the service; teardown sends a best-effort hangup. Cookie access is limited to the app's own WebView cookie jar. This does not create a platform bypass token or alternate login.

Retest on the physical phones: sustained two-way voice while locked, speaker switching, Android ongoing notification, stop/hangup, panel minimisation, and incoming notifications. Renderer/audio restrictions on individual devices may still require a fully native media engine.

### Personal release 1.4 — 29 October 2026

The user confirmed on their two phones: audio/video calling, earpiece output, sustained two-way audio with the screen locked after 1.3, and incoming notification plus answering after removing the app from Recents. These are physical-device observations for those phones, not a guarantee for all Android devices/networks. Force-stop remains different from removing from Recents; reopening is required after force-stop. STUN-only calls may fail on restrictive networks because there is no TURN relay.

Version 1.4 retains the 1.3 media/service implementation, removes test setup copy and the FCM-token clipboard button, labels the primary in-app launcher action “Enter Happiness ♡”, and groups phone linking/browser fallback under notification settings. The APK is a non-debuggable, signed personal distribution build, compatible with earlier installs using the same application id and signing certificate. It is distributed directly, not through Google Play. Do not rotate its signing key for updates.

The temporary partner account is still the user's test Gmail. Replacing that account requires both a Site invitation/access change and updating the in-app partner editor setting. No private admin credential is included in the APK or source archive. Firebase and hosted services remain subject to their quotas; offline calling and guaranteed connectivity on every network are not claimed.

### Personal release 1.5 — uncluttered entrance and call controls

The entrance has one primary button, “Enter Happiness ♡”. Device linking, notification permission, browser fallback and version information are in a settings dialog behind a small gear. The in-app homepage no longer has a native title/earpiece/speaker/settings toolbar. Speaker/earpiece selection is inside the connected-call panel and uses the existing origin-restricted native route bridge; it only changes its selected state after Android acknowledges the route. App phone settings can also be opened from the existing in-app phone notifications card. Media capture, background heartbeat, foreground service and notification reception are unchanged.

### Owner, Co-admin and Guest access manager — 29 October 2026

The Invite access card now provides one email-and-role form, the existing single partner/Co-admin role, a shared guest invitation checklist, and explicit confirmation for removing a role/checklist entry. Co-admins have existing content editing, calling, and guest-checklist management; only the original Owner can assign/remove the single Co-admin. Guests cannot read invitation email lists or perform administrative writes. Existing test partner grants are retained. Partner insertion uses a single conditional SQL statement to avoid concurrent requests creating multiple partners. Role removal takes effect on subsequent authenticated requests.

Hosting access remains controlled by the platform's invite-only Site sharing. The hosted application has no eligible invitation binding, so it does not send invitations, assert acceptance, or revoke hosting viewer grants. Preparing a Guest entry alone grants no Site access. The UI labels all hosting invitation statuses as unverified and provides an exact request to copy into ChatGPT, or instructions to use Site Share settings. Removing a checklist entry does not revoke a Site viewer; removing a Co-admin only removes application editing/calling rights. This is a two-step access workflow, not completed one-click invitation delivery. No hosting audience change or automatic email sends occur.

Checks: TypeScript and Miniflare integration tests cover anonymous/guest denials, co-admin content rights and revoke, original Owner protection, validation, cross-origin writes, duplicate submissions and truthful platform-invite status. This change uses the live website in the existing APK 1.5; Android media, push and background calling implementation are unchanged. New romantic feature modules are still pending; earlier unpublished working-directory changes were lost before source synchronization.

### Memory places / map — 29 October 2026

“Jahan hum mile” is available from the homepage and footer. Owner and Co-admin create/edit/delete place entries with a title, story, real calendar date, a gallery or uploaded image, an optional HTTPS Google Maps/OpenStreetMap link and optional coordinate pair. Guests can read the shared entries. The form can infer coordinates from common full Maps links; short Maps links open externally. All place data remains visible to invited Site visitors.

An embedded OpenStreetMap marker loads only after the visitor explicitly clicks “Map yahin dekho”; initial page rendering does not fetch map tiles or share location. No live location tracking, background GPS capture or new Android location permissions. Map links are host/scheme allowlisted, coordinates range-validated, and storage references checked server-side. Deleting a gallery record preserves an uploaded image referenced by a place. Deleting a place removes its entry, retaining image storage to avoid accidental loss. Photo uploads remain capped at 50 MB. Up to 300 places are listed/created through this interface. A map/API provider outage does not prevent viewing the saved text/photo.

Validation: TypeScript, places-model tests and expanded Miniflare integration tests passed, including guest-write denials, real/leap dates, invalid pin/link rejection, CRUD and a unique place image surviving gallery deletion. Browser preview routing remained unavailable in this environment, so the map and mobile visual experience have not been verified in-browser/on-device. Existing APK 1.5 loads this live website update without native changes.

### Requested GitHub migration — pending destination

The user explicitly requested a NEW GitHub account for this project. The currently connected account is arifagroworks; do not put this personal project in that account or the AAW business repository without explicit direction. The new account username/profile URL and connected repository write access are still required. No GitHub transfer has occurred.

GitHub Pages can host the separate public introduction frontend; it cannot run this app's Cloudflare D1/R2 Worker APIs or provide its platform-authenticated identity by itself. Full relocation needs a replacement authenticated backend and APK-origin adjustments, plus migration verification. Keep the existing invite-only deployment running until that migration is ready. Never copy service account credentials, source-credential tokens, signing keystores, user data or private uploaded memories into a public GitHub repository.

## Latest release — shared connection tools (30 October 2026)
- Voice Postcards under Love notes: explicit microphone capture, preview and save.
- Memory Movie: select up to 12 gallery photos, choose 2–5 seconds each, optional original synthesized instrumental, render a downloadable video on device, or save to the shared gallery. MediaRecorder/canvas support is required; export is real-time with the page visible. No microphone or camera is used.
- Love Calendar: editable special dates, annual recurrence, month view and India-time countdowns. No scheduled notifications are sent. Leap-day anniversaries recur in leap years.
- Couple Questions: twenty optional prompts, one independently editable answer per partner per question. Answers are shared with all invited guests; there are no scores or streaks.
- Together Room: shared gallery memory/activity, owner/coadmin playback controls and five-second foreground polling. Browser autoplay may need a local Play tap. This is approximate shared playback, not screen sharing or presence tracking.
- Uses existing records/settings storage; no schema change or data reset. New /api/connection enforces authenticated viewing, owner/coadmin changes and CSRF checks.
- Browser preview remains unavailable in this environment; physical-device recording/export and responsive visual verification are unverified.
- github-pages/ contains an isolated, photo-free public welcome page. It is not published yet and is not a backend migration.

## Supabase migration (30 October 2026)
The standalone React build lives in migration/frontend, with a server-only PostgreSQL/Storage adapter in migration/edge. The Supabase API verifies every user token with Supabase Auth and checks an explicit live invite allowlist before dispatching. Direct table access is denied to browser roles. Private storage uses expiring signed URLs. One-time invitation links are generated for Owner/Co-admin to share manually; no invitation email is falsely claimed sent. Only the original verified Owner can activate the new Owner identity through the original private app; the recipient sets their own password in the new app. No service-role/Firebase/admin secrets are in the frontend.

Media migration copied and SHA-256 verified 14 referenced/original files. Existing legacy records and reactions were preserved. Live disposable-account tests passed for roles, CRUD, invitations, invite replay protection, calls, date checks, signed media and immediate membership revocation. Test identities were removed. Real-phone media playback/export and Android origin migration remain unverified. The existing signed APK 1.5 still opens the original host; do not claim it uses the new backend.

Build the GitHub frontend with node migration/build-frontend.mjs. Large ONNX WASM loads from the pinned onnxruntime-web 1.21.0 CDN asset. Authored source and dependencies retain their original licences.
