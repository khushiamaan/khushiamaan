import ts from 'typescript';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const code=ts.transpileModule(fs.readFileSync('app/native-audio.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const sent=[];const context={exports:{},window:{},setTimeout,clearTimeout};vm.runInNewContext(code,context);const api=context.exports;
assert.equal(api.hasNativeAudio(),false);assert.equal((await api.nativeAudio('prepare')).ok,true);assert.equal(sent.length,0);
context.window.KhushiNative={postMessage:data=>sent.push(JSON.parse(data))};
assert.equal(api.hasNativeAudio(),true);
const prepare=api.nativeAudio('prepare',{video:false});const route=api.nativeAudio('route',{speaker:true});
const bridge=context.window.KhushiNative;bridge.onmessage({data:'invalid JSON'});bridge.onmessage({data:JSON.stringify({id:'unmatched',ok:true})});
bridge.onmessage({data:JSON.stringify({id:sent[1].id,ok:false,message:'No earpiece'})});await assert.rejects(route,/No earpiece/);
bridge.onmessage({data:JSON.stringify({id:sent[0].id,ok:true,message:'Ready'})});assert.equal((await prepare).message,'Ready');
const end=api.nativeAudio('end');bridge.onmessage({data:JSON.stringify({id:sent[2].id,ok:true})});await end;
assert.equal(sent.map(x=>x.action).join(','),'prepare,route,end');
console.log('PASS: native audio bridge browser fallback, malformed messages, request correlation, route rejection, end acknowledgement.');

const session=api.nativeAudio('session',{callId:'call-one',accessToken:'access',refreshToken:'refresh',expiresAt:123});
bridge.onmessage({data:JSON.stringify({id:sent[3].id,ok:true})});await session;assert.equal(api.nativeCallId(),'call-one');assert.equal(sent[3].accessToken,'access');
const updated=api.nativeAudio('session',{callId:'call-one',accessToken:'new-access',refreshToken:'new-refresh',expiresAt:456});
bridge.onmessage({data:JSON.stringify({id:sent[4].id,ok:true})});await updated;assert.equal(sent[4].refreshToken,'new-refresh');
const stopped=api.nativeAudio('end');assert.equal(api.nativeCallId(),'');bridge.onmessage({data:JSON.stringify({id:sent[5].id,ok:true})});await stopped;
console.log('PASS: native active-call session credential refresh and immediate end clearing.');

const output=api.nativeAudio('route',{speaker:false,picker:true,mode:'auto'});assert.equal(sent[6].picker,true);assert.equal(sent[6].mode,'auto');bridge.onmessage({data:JSON.stringify({id:sent[6].id,ok:true,route:'USB / Type-C earphones'})});assert.equal((await output).route,'USB / Type-C earphones');
console.log('PASS: output picker / automatic mode request and native route-label acknowledgement.');
