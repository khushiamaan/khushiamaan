import ts from 'typescript';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
class Stream{constructor(tracks){this.tracks=tracks;}getAudioTracks(){return this.tracks.filter(t=>t.kind==='audio');}}
const context={exports:{},MediaStream:Stream};vm.runInNewContext(ts.transpileModule(fs.readFileSync('app/call-playback.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText,context);
const {attachCallPlayback}=context.exports;const track={id:'voice',kind:'audio'},videoTrack={id:'camera',kind:'video'},stream=new Stream([track,videoTrack]);
let blocked=0;const audio={srcObject:null,play:()=>Promise.resolve()},video={muted:false,srcObject:null,play:()=>Promise.resolve()};
attachCallPlayback(stream,audio,video,()=>blocked++);assert.equal(audio.srcObject.tracks.length,1);assert.equal(audio.srcObject.tracks[0],track);assert.equal(video.muted,true);assert.equal(video.srcObject,stream);
const audioSource=audio.srcObject;attachCallPlayback(stream,audio,null,()=>blocked++);assert.equal(audio.srcObject,audioSource);
audio.play=()=>Promise.reject(Error('blocked'));attachCallPlayback(stream,audio,null,()=>blocked++);await new Promise(r=>setImmediate(r));assert.equal(blocked,1);
console.log('PASS: call voice is audio-only, video is muted, voice remains attached without panel video, blocked playback is reported.');
