import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdir} from 'node:fs/promises';
const require=createRequire(import.meta.url),wrangler=createRequire(require.resolve('wrangler'));
await mkdir('.sites-runtime/tests',{recursive:true});await wrangler('esbuild').build({entryPoints:['app/voice-recorder.ts'],bundle:true,platform:'node',format:'esm',outfile:'.sites-runtime/tests/voice-recorder.mjs'});
const {captureVoice,voiceFile,voiceMime,VOICE_LIMIT_BYTES}=await import('../.sites-runtime/tests/voice-recorder.mjs');
class Recorder {
 static isTypeSupported(m){return m==='audio/webm;codecs=opus'}
 static last;
 constructor(stream,options){Recorder.last=this;this.state='inactive';this.mimeType=options?.mimeType||'audio/webm'}
 start(){this.state='recording'}
 stop(){this.state='inactive';queueMicrotask(()=>{this.ondataavailable?.({data:new Blob(['voice'])});this.onstop?.()})}
}
function stream(){const track={stopped:false,stop(){this.stopped=true}};return {getTracks:()=>[track],track}}
assert.equal(voiceMime(Recorder),'audio/webm;codecs=opus');
let result=[],s=stream(),c=captureVoice(s,Recorder,(...args)=>result.push(args));c.stop();c.stop();await new Promise(r=>setImmediate(r));assert.equal(result.length,1);assert.equal(result[0][0].size,5);assert.ok(s.track.stopped);const file=voiceFile(result[0][0]);assert.equal(file.type,'audio/webm');assert.equal(file.name,'voice-postcard.webm');
result=[];s=stream();c=captureVoice(s,Recorder,(...a)=>result.push(a));c.stop(true);await new Promise(r=>setImmediate(r));assert.equal(result.length,0);assert.ok(s.track.stopped);
result=[];s=stream();c=captureVoice(s,Recorder,(...a)=>result.push(a));Recorder.last.onerror();await new Promise(r=>setImmediate(r));assert.equal(result.length,1);assert.equal(result[0][0],null);assert.ok(s.track.stopped);
result=[];s=stream();c=captureVoice(s,Recorder,(...a)=>result.push(a));Recorder.last.ondataavailable({data:new Blob([new Uint8Array(VOICE_LIMIT_BYTES+1)])});await new Promise(r=>setImmediate(r));assert.equal(result.length,1);assert.equal(result[0][0],null);assert.ok(s.track.stopped);
s=stream();class Broken extends Recorder{constructor(){throw Error('construction failed')}}assert.throws(()=>captureVoice(s,Broken,()=>{}));assert.ok(s.track.stopped);
s=stream();class BrokenStart extends Recorder{start(){throw Error('start failed')}}assert.throws(()=>captureVoice(s,BrokenStart,()=>{}));assert.ok(s.track.stopped);
assert.throws(()=>voiceFile(new Blob([],{type:'audio/webm'})));assert.throws(()=>voiceFile(new Blob(['x'],{type:'video/webm'})));
assert.equal(voiceFile(new Blob(['x'],{type:'audio/mp4;codecs=mp4a.40.2'})).name,'voice-postcard.m4a');
const realTimeout=globalThis.setTimeout,realClear=globalThis.clearTimeout;let limitCallback,limit;
try{globalThis.setTimeout=(cb,ms)=>{limitCallback=cb;limit=ms;return 1};globalThis.clearTimeout=()=>{};result=[];s=stream();captureVoice(s,Recorder,(...a)=>result.push(a));assert.equal(limit,120000);limitCallback();await new Promise(r=>setImmediate(r));assert.ok(s.track.stopped);assert.equal(result.length,1)}finally{globalThis.setTimeout=realTimeout;globalThis.clearTimeout=realClear}
console.log('PASS: voice format normalization, preview file validation, microphone cleanup, discard, recorder errors, size and duration limits, duplicate stop and start failures.');
