import {createRequire} from 'node:module';
import {generateKeyPairSync,verify} from 'node:crypto';
import {resolve} from 'node:path';
import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const req=createRequire(import.meta.url),wr=createRequire(req.resolve('wrangler'));
const {build}=wr('esbuild'),{Miniflare,createFetchMock}=wr('miniflare');
const {privateKey,publicKey}=generateKeyPairSync('rsa',{modulusLength:2048});
const fakeAccount={project_id:'khushi-forever-2cbbe',client_email:'test@example.invalid',private_key:privateKey.export({type:'pkcs8',format:'pem'})};
await build({stdin:{contents:`import {notifyIncoming} from './app/push';export default{async fetch(){return Response.json(await notifyIncoming('partner@example.test','11111111-1111-4111-8111-111111111111','audio',12345))}}`,resolveDir:process.cwd(),loader:'ts'},bundle:true,format:'esm',platform:'neutral',outfile:'.sites-runtime/tests/push-worker.mjs',external:['cloudflare:workers'],plugins:[{name:'auth-stub',setup(b){b.onResolve({filter:/chatgpt-auth$/},()=>({path:'auth',namespace:'test'}));b.onLoad({filter:/.*/,namespace:'test'},()=>({contents:'export async function getChatGPTUser(){return null}',loader:'js'}))}}]});
let oauthChecks=0,pushChecks=0;
const outboundService=async request=>{
 const url=new URL(request.url),text=await request.text();
 if(url.origin==='https://oauth2.googleapis.com'&&url.pathname==='/token'){
  const form=new URLSearchParams(text),jwt=form.get('assertion');assert.ok(jwt);const[h,p,sig]=jwt.split('.');
  assert.equal(verify('RSA-SHA256',Buffer.from(h+'.'+p),publicKey,Buffer.from(sig,'base64url')),true);
  const claims=JSON.parse(Buffer.from(p,'base64url'));assert.equal(claims.scope,'https://www.googleapis.com/auth/firebase.messaging');assert.equal(claims.aud,'https://oauth2.googleapis.com/token');assert.equal(claims.iss,fakeAccount.client_email);assert.ok(claims.exp>claims.iat);assert.ok(!text.includes('PRIVATE KEY'));oauthChecks++;
  return Response.json({access_token:'test-only-access-token',expires_in:3600});
 }
 if(url.origin==='https://fcm.googleapis.com'&&url.pathname==='/v1/projects/khushi-forever-2cbbe/messages:send'){
  assert.equal(request.headers.get('Authorization'),'Bearer test-only-access-token');const body=JSON.parse(text);assert.equal(body.message.android.priority,'high');assert.equal(body.message.android.ttl,'60s');assert.equal(body.message.data.kind,'incoming_call');assert.equal(body.message.data.mode,'audio');assert.equal(body.message.data.call_id,'11111111-1111-4111-8111-111111111111');assert.ok(!text.includes('PRIVATE KEY'));pushChecks++;
  return pushChecks===1?Response.json({name:'test-message'}):Response.json({error:{details:[{errorCode:'UNREGISTERED'}]}},{status:404});
 }
 throw new Error('Unexpected outbound request blocked by test.');
};
const mf=new Miniflare({modules:true,scriptPath:resolve('.sites-runtime/tests/push-worker.mjs'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],bindings:{FIREBASE_SERVICE_ACCOUNT_JSON:JSON.stringify(fakeAccount)},d1Databases:['DB'],outboundService});
try{const db=await mf.getD1Database('DB');await db.prepare(await readFile('drizzle/0002_graceful_kulan_gath.sql','utf8')).run();await db.prepare('INSERT INTO devices(id,email,token,nickname,created) VALUES(?,?,?,?,?)').bind('test-id','partner@example.test','fake-fcm-token-not-a-real-device','Test',1).run();
 const sent=await(await mf.dispatchFetch('https://test.local/')).json();assert.deepEqual(sent,{status:'sent',sent:1});assert.equal(oauthChecks,1);assert.equal(pushChecks,1);

 const failed=await(await mf.dispatchFetch('https://test.local/')).json();assert.deepEqual(failed,{status:'delivery_failed',sent:0});assert.equal(oauthChecks,1,'cached short-lived OAuth token reused');assert.equal((await db.prepare('SELECT id FROM devices').all()).results.length,0,'expired token removed');
console.log('PASS: push signing, OAuth claims, high-priority FCM payload, token caching and invalid-device cleanup. No real notifications sent.');
}finally{await mf.dispose()}
