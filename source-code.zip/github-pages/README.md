# Public welcome page — ready, not yet published

This folder contains a public welcome page only. It opens the current invite-only app on its existing host. It is NOT a frontend/backend migration and cannot host private records or authenticated calls itself.

Publish only this folder in a separate public repository on the karanwolf93 account, then enable Pages (main branch / root), or use the supplied manual workflow in this source repository if its Pages plan/access supports it. Keep this source repository private unless its visibility change is explicitly approved. On GitHub Free, Pages requires a public repository; this is why a separate public welcome-page repository is recommended.

The GitHub browser is currently signed out. Connected GitHub tools support file operations, but not creating repositories or configuring Pages in this session. No github.io URL is verified live yet.

Full migration still needs a separately accessible authenticated backend, data/media transfer, invitation flows and an Android origin/signing update. Keep the working host while those prerequisites remain unresolved.
