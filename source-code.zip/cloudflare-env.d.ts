declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    OWNER_EMAIL?: string;
    FIREBASE_SERVICE_ACCOUNT_JSON?: string;
    BUCKET?: R2Bucket;
  }
}
