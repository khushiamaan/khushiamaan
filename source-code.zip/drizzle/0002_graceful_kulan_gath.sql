CREATE TABLE `devices` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`token` text NOT NULL,
	`nickname` text DEFAULT 'Android phone' NOT NULL,
	`created` integer NOT NULL
);
