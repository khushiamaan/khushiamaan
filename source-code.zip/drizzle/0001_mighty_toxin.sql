CREATE TABLE `calls` (
	`slot` text PRIMARY KEY NOT NULL,
	`id` text NOT NULL,
	`caller` text NOT NULL,
	`callee` text NOT NULL,
	`mode` text NOT NULL,
	`offer` text NOT NULL,
	`answer` text DEFAULT '' NOT NULL,
	`state` text NOT NULL,
	`created` integer NOT NULL,
	`caller_seen` integer NOT NULL,
	`callee_seen` integer DEFAULT 0 NOT NULL
);
