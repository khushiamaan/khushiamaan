CREATE TABLE `editors` (
	`email` text PRIMARY KEY NOT NULL
);
--> statement-breakpoint
CREATE TABLE `hearts` (
	`record` text NOT NULL,
	`user` text NOT NULL,
	PRIMARY KEY(`record`, `user`)
);
--> statement-breakpoint
CREATE TABLE `records` (
	`id` text PRIMARY KEY NOT NULL,
	`type` text NOT NULL,
	`title` text NOT NULL,
	`body` text DEFAULT '' NOT NULL,
	`date` text DEFAULT '' NOT NULL,
	`media` text DEFAULT '' NOT NULL,
	`mime` text DEFAULT '' NOT NULL,
	`done` integer DEFAULT 0 NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
