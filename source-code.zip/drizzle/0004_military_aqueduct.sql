CREATE TABLE `places` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`story` text DEFAULT '' NOT NULL,
	`date` text DEFAULT '' NOT NULL,
	`photo` text DEFAULT '' NOT NULL,
	`map_url` text DEFAULT '' NOT NULL,
	`latitude` text DEFAULT '' NOT NULL,
	`longitude` text DEFAULT '' NOT NULL,
	`created` integer NOT NULL,
	`updated` integer NOT NULL
);
