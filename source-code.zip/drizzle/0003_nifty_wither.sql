CREATE TABLE `access_requests` (
	`email` text PRIMARY KEY NOT NULL,
	`role` text NOT NULL,
	`created` integer NOT NULL
);
