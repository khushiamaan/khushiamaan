import{build}from'vite';import react from'@vitejs/plugin-react';import{resolve}from'node:path';
await build({configFile:false,root:resolve('migration/frontend'),base:'/khushiamaan/',plugins:[react(),{name:'portable-transport',enforce:'pre',resolveId(id,importer){if(id==='./access-manager'&&importer?.includes('/app/'))return resolve('migration/frontend/access-manager.tsx');if(id==='./client-api'&&importer?.includes('/app/'))return resolve('migration/frontend/transport.ts')}}],build:{outDir:resolve('.sites-runtime/github-app'),emptyOutDir:true,rollupOptions:{external:['https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.95.0/+esm']}}});

// ONNX's pinned package supplies the identical wasm asset through its public CDN.
// Keep private photos out of the GitHub artifact and avoid a redundant 24 MB blob.
const {readdir,readFile,writeFile,unlink}=await import('node:fs/promises');
const dir=resolve('.sites-runtime/github-app/assets');const names=await readdir(dir);const wasm=names.find(n=>n.endsWith('.wasm'));
if(wasm){for(const name of names.filter(n=>n.endsWith('.js')||n.endsWith('.mjs'))){const file=resolve(dir,name),before=await readFile(file,'utf8'),after=before.replaceAll('/khushiamaan/assets/'+wasm,'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.21.0/dist/ort-wasm-simd-threaded.jsep.wasm');if(after!==before)await writeFile(file,after)}await unlink(resolve(dir,wasm))}
