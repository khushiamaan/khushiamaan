-- Independent Khushi Forever project. No changes to the AAW database.
create schema if not exists khushi_private;
revoke all on schema khushi_private from public, anon, authenticated;
grant usage on schema khushi_private to service_role;
create table public.records(id text primary key,type text not null,title text not null,body text not null default '',date text not null default '',media text not null default '',mime text not null default '',done integer not null default 0,created text not null);
create table public.settings(key text primary key,value text not null);
create table public.editors(email text primary key);
create table public.access_requests(email text primary key,role text not null,created bigint not null);
create table public.hearts(record text not null,"user" text not null,primary key(record,"user"));
create table public.places(id text primary key,title text not null,story text not null default '',date text not null default '',photo text not null default '',map_url text not null default '',latitude text not null default '',longitude text not null default '',created bigint not null,updated bigint not null);
create table public.calls(slot text primary key,id text not null,caller text not null,callee text not null,mode text not null,offer text not null,answer text not null default '',state text not null,created bigint not null,caller_seen bigint not null,callee_seen bigint not null default 0);
create table public.devices(id text primary key,email text not null,token text not null,nickname text not null default 'Android phone',created bigint not null);
create table khushi_private.members(email text primary key,created bigint not null);
create table khushi_private.config(key text primary key,value text not null);
create table khushi_private.files(key text primary key,mime text not null,size bigint not null,name text not null default '');
create index devices_email_created on public.devices(email,created desc);
create index records_media on public.records(media);
create index places_photo on public.places(photo);
-- Only the authenticated API function receives service-role credentials. Browsers
-- have no direct table access, even when holding a valid ordinary user token.
do $$declare t text;begin foreach t in array array['records','settings','editors','access_requests','hearts','places','calls','devices'] loop execute format('alter table public.%I enable row level security',t);execute format('revoke all on public.%I from public,anon,authenticated',t);execute format('grant all on public.%I to service_role',t);end loop;end$$;
grant all on all tables in schema khushi_private to service_role;
-- A server-only compatibility runner preserves existing parameterized, atomic
-- D1 operations while PostgreSQL supplies transactions. Never grant to clients.
create function public.khushi_run(statements jsonb) returns jsonb
language plpgsql security invoker set search_path=pg_catalog,public,khushi_private as $$
declare s jsonb;q text;parts text[];p jsonb;i integer;outrows jsonb;answers jsonb='[]'::jsonb;begin
 if jsonb_typeof(statements)<>'array' or jsonb_array_length(statements)>100 then raise exception 'Invalid batch';end if;
 for s in select * from jsonb_array_elements(statements) loop
 q:=s->>'sql';p:=coalesce(s->'params','[]'::jsonb);
 if length(q)>12000 or q!~* '^\s*(SELECT|INSERT|UPDATE|DELETE)\s' or position(';' in q)>0 then raise exception 'Invalid statement';end if;
 parts:=string_to_array(q,'?');if array_length(parts,1)-1<>jsonb_array_length(p) then raise exception 'Parameter count mismatch';end if;
 q:=parts[1];for i in 1..jsonb_array_length(p) loop q:=q||case when p->(i-1)='null'::jsonb then 'NULL' else quote_literal(p->>(i-1)) end||parts[i+1];end loop;
 if q~* '^\s*SELECT\s' then execute 'select coalesce(jsonb_agg(to_jsonb(result)),''[]''::jsonb) from ('||q||') result' into outrows;
 else execute 'with result as ('||q||' returning *) select coalesce(jsonb_agg(to_jsonb(result)),''[]''::jsonb) from result' into outrows;end if;
 answers:=answers||jsonb_build_array(jsonb_build_object('results',outrows,'success',true,'meta',jsonb_build_object('changes',case when q~* '^\s*SELECT\s' then 0 else jsonb_array_length(outrows) end)));
 end loop;return answers;end$$;
revoke all on function public.khushi_run(jsonb) from public,anon,authenticated;
grant execute on function public.khushi_run(jsonb) to service_role;
-- Remove default event-trigger execution grants reported by the fresh project's advisor.
revoke execute on function public.rls_auto_enable() from public,anon,authenticated;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('khushi-media','khushi-media',false,52428800,array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime','audio/mpeg','audio/mp4','audio/webm','audio/ogg','audio/wav']) on conflict(id) do nothing;
