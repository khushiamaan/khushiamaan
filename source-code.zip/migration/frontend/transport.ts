import {nativeAudio,nativeCallId} from '../../app/native-audio';
// Supabase uses its supported session/JWT flow; no project secret enters this bundle.
// @ts-ignore Pinned CDN module stays external to the build.
import {createClient} from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.95.0/+esm';
export const portable=true;
export const config={url:'https://gqcyskripxesrryfunhv.supabase.co',key:'sb_publishable_vtVuJ4IO18-c3uJoRJvnIw_rTMi7jrT',base:'/khushiamaan/'};
export const supabase=createClient(config.url,config.key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
const urls=new Map<string,string>();
export function mediaUrl(path:string){if(!path)return '';if(path.startsWith('blob:')||path.startsWith('data:'))return path;return urls.get(path)||''}
export function sitePath(path:string){if(path.startsWith('/signout'))return config.base+'?logout=1';if(path.startsWith('/signin'))return config.base+'?logout=1';return 'https://amaan-ki-khushi.honestghost8.chatgpt.site'+path}
export async function apiFetch(input:RequestInfo|URL,init?:RequestInit){const path=String(input);if(!path.startsWith('/api/')){
 const target=urls.get(path);if(target)return fetch(target,init);if(path.startsWith('/photos/')||path.startsWith('/api/media/'))return new Response('Private media URL expired. Reload memories.',{status:410});return fetch(input,init)
 }
 if(path.startsWith('/api/media/')&&urls.has(path))return fetch(urls.get(path)!,init);
 const {data}=await supabase.auth.getSession();const token=data.session?.access_token;if(!token)return new Response('Dobara sign in karein.',{status:401});
 const headers=new Headers(init?.headers);headers.set('Authorization','Bearer '+token);headers.set('apikey',config.key);
 const r=await fetch(config.url+'/functions/v1/khushi-api'+path,{...init,headers});
 if(r.ok&&r.headers.get('content-type')?.includes('application/json')){const d:any=await r.clone().json();for(const [key,value]of Object.entries(d._mediaUrls||{}))if(typeof value==='string')urls.set(key,value)}return r
}

export async function callCredentials(){const {data}=await supabase.auth.getSession();const s=data.session;if(!s)throw new Error('Dobara sign in karein.');return {accessToken:s.access_token,refreshToken:s.refresh_token,expiresAt:s.expires_at}}
// Only an active, explicit call shares credentials with the origin-restricted native service.
supabase.auth.onAuthStateChange((_event:string,s:any)=>{const id=nativeCallId();if(!id)return;setTimeout(()=>{if(!s)nativeAudio('end').catch(()=>{});else nativeAudio('session',{callId:id,accessToken:s.access_token,refreshToken:s.refresh_token,expiresAt:s.expires_at}).catch(()=>{})},0)});
window.addEventListener('khushi-auth-refreshed',((e:CustomEvent)=>{const d=e.detail;if(!nativeCallId()||!d||typeof d.access_token!=='string'||typeof d.refresh_token!=='string')return;supabase.auth.setSession({access_token:d.access_token,refresh_token:d.refresh_token}).catch(()=>{})}) as EventListener);
