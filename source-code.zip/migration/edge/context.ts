import {AsyncLocalStorage} from 'node:async_hooks';
export const requestContext=new AsyncLocalStorage<any>();
export function current(){const c=requestContext.getStore();if(!c)throw Error('Missing request context');return c}
export async function getChatGPTUser(){return current().user}
export const env=new Proxy({},{get:(_,key)=>current().env[key]});
