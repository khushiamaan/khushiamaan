import {createClient} from 'npm:@supabase/supabase-js@2.95.0';
import {requestContext} from './context';
import {activateOwner} from './activate';
import {PostgresD1,PrivateBucket} from './adapter';
import * as access from './access';
import * as calls from '../../app/api/calls/route';
import * as devices from '../../app/api/devices/route';
import * as records from '../../app/api/records/route';
import * as settings from '../../app/api/settings/route';
import * as upload from '../../app/api/upload/route';
import * as media from '../../app/api/media/[id]/route';
import * as data from '../../app/api/data/route';
import * as places from '../../app/api/places/route';
import * as connection from '../../app/api/connection/route';
import {initialPhotos} from '../../app/server';
const origin='https://khushiamaan.github.io';
const cors={'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'authorization,apikey,content-type,range','Access-Control-Allow-Methods':'GET,POST,PATCH,DELETE,OPTIONS','Access-Control-Expose-Headers':'content-range,accept-ranges,content-length','Vary':'Origin','Cache-Control':'private, no-store','Referrer-Policy':'no-referrer'};
const url=Deno.env.get('SUPABASE_URL')!;
const secrets=JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')||'{}');const key=secrets.default||Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const admin=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}}),db=new PostgresD1(admin),bucket=new PrivateBucket(admin,db);
function respond(r:Response){const h=new Headers(r.headers);for(const[k,v]of Object.entries(cors))h.set(k,v);return new Response(r.body,{status:r.status,headers:h})}
async function config(){const rows=(await db.prepare('SELECT key,value FROM khushi_private.config').all()).results;return Object.fromEntries(rows.map((r:any)=>[r.key,r.value]))}
async function signedPaths(paths:string[]){const pairs=[...new Set(paths.filter(p=>/^\/(photos\/[^?#]+|api\/media\/[a-f0-9-]{36})$/.test(p)))].map(p=>({path:p,key:p.startsWith('/photos/')?'seed/'+p.split('/').pop():p.split('/').pop()!}));if(!pairs.length)return{};const {data,error}=await admin.storage.from('khushi-media').createSignedUrls(pairs.map(p=>p.key),3600);if(error)return{};return Object.fromEntries(pairs.map((p,i)=>[p.path,data?.[i]?.signedUrl||'']).filter(p=>p[1]))}
export async function handler(req:Request):Promise<Response>{
 if(req.method==='OPTIONS')return respond(new Response(null,{status:204}));
 const incomingOrigin=req.headers.get('origin');if(incomingOrigin&&incomingOrigin!==origin)return new Response('Origin not allowed',{status:403});
 try{const path=new URL(req.url).pathname.replace(/^\/khushi-api/,'');const awaitConfig=path==='/_activate-owner'?await config():null;
 if(path==='/health'){return respond(Response.json({ok:true,service:'Khushi Forever API',authentication:'Supabase verified user + invite allowlist',migration:'media-verified'}))}
 if(path==='/_activate-owner'&&req.method==='POST')return activateOwner(req,db,admin,awaitConfig);
 const auth=req.headers.get('authorization')||'';if(!auth.startsWith('Bearer '))return respond(new Response('Sign in required',{status:401}));
 const {data:authData,error}=await admin.auth.getUser(auth.slice(7));if(error||!authData.user?.email||!authData.user.email_confirmed_at)return respond(new Response('Verified sign-in required',{status:401}));
 const account=authData.user,email=account.email!.toLowerCase(),cfg=await config(),primary=email===cfg.OWNER_EMAIL;
 if(!primary&&!await db.prepare('SELECT email FROM khushi_private.members WHERE email=?').bind(email).first())return respond(new Response('Owner se invite access maangein.',{status:403}));
 const editor=!!await db.prepare('SELECT email FROM editors WHERE email=?').bind(email).first(),legacy=await db.prepare('SELECT value FROM khushi_private.config WHERE key=?').bind('identity:'+email).first<any>();
 const user={userId:legacy?.value||account.id,email,displayName:String(account.user_metadata?.full_name||email).slice(0,150),fullName:null,primary,owner:primary||editor};
 const env={DB:db,BUCKET:bucket,OWNER_EMAIL:cfg.OWNER_EMAIL,FIREBASE_SERVICE_ACCOUNT_JSON:cfg.FIREBASE_SERVICE_ACCOUNT_JSON};
 return await requestContext.run({user,env,db,admin},async()=>{
 const name=path.split('/')[2],id=path.split('/')[3],handlers:any={access,calls,devices,records,settings,upload,media,data,places,connection};const fn=handlers[name]?.[req.method];if(!fn)return respond(new Response('Not found',{status:404}));
 // Requests passed here already have a verified bearer and allowed origin. Keep
 // legacy same-origin CSRF checks without weakening either hosted API.
 const headers=new Headers(req.headers);headers.delete('origin');headers.delete('sec-fetch-site');const localReq=new Request('https://app.local'+path,{method:req.method,headers,body:['GET','HEAD'].includes(req.method)?undefined:req.body,duplex:'half'} as RequestInit);
 let result=await fn(localReq,{params:Promise.resolve({id})});
 if(result.ok&&result.headers.get('content-type')?.includes('application/json')){const obj:any=await result.json();const paths:string[]=[...initialPhotos.map(p=>'/photos/'+p[2])];for(const r of obj.records||[])if(r.media)paths.push(r.media);for(const p of obj.places||[])if(p.photo)paths.push(p.photo);if(obj.settings){paths.push(obj.settings.cover||'',obj.settings.music||'')}if(obj.media)paths.push(obj.media);obj._mediaUrls=await signedPaths(paths);result=Response.json(obj,{status:result.status})}
 return respond(result);
 });
 }catch(e){console.error('Khushi API request failed: '+(e instanceof Error?e.name:'unknown'));return respond(Response.json({error:'Abhi request poori nahi hui. Dobara try karein.'},{status:500}))}
}
Deno.serve(handler);
