export function postgresSQL(sql:string){let s=sql.replace(/\buser\b/g,'"user"');if(/^INSERT OR IGNORE /i.test(s)){s=s.replace(/^INSERT OR IGNORE /i,'INSERT ');if(!/ON CONFLICT/i.test(s))s+=' ON CONFLICT DO NOTHING'}return s}
export class PostgresD1{
 constructor(public admin:any){}
 prepare(sql:string){return new Statement(this,postgresSQL(sql),[])}
 async batch(items:Statement[]){const {data,error}=await this.admin.rpc('khushi_run',{statements:items.map(i=>({sql:i.sql,params:i.params}))});if(error)throw Error('Database operation failed: '+error.code);return data}
}
class Statement{
 constructor(public db:PostgresD1,public sql:string,public params:unknown[]){}
 bind(...params:unknown[]){return new Statement(this.db,this.sql,params)}
 async all<T=any>():Promise<{results:T[]}>{return (await this.db.batch([this]))[0]}
 async first<T=any>():Promise<T|null>{return (await this.all<T>()).results[0]||null}
 async run(){return (await this.db.batch([this]))[0]}
}
export class PrivateBucket{
 constructor(public admin:any,public db:PostgresD1){}
 async head(key:string){const f=await this.db.prepare('SELECT * FROM khushi_private.files WHERE key=?').bind(key).first<any>();return f?{key,size:Number(f.size),httpMetadata:{contentType:f.mime}}:null}
 async put(key:string,body:ReadableStream|Blob|Uint8Array,options:any){const mime=options.httpMetadata?.contentType||'application/octet-stream';const {data,error}=await this.admin.storage.from('khushi-media').upload(key,body,{contentType:mime,upsert:false});if(error)throw Error('Private media upload failed');const info=await this.admin.storage.from('khushi-media').info(key);const size=body instanceof Uint8Array?body.byteLength:body instanceof Blob?body.size:Number(info.data?.size??info.data?.metadata?.size??0);await this.db.prepare('INSERT INTO khushi_private.files(key,mime,size,name) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET mime=excluded.mime,size=excluded.size').bind(key,mime,size,options.customMetadata?.name||key).run();return data}
 async get(key:string,options:any){const f=await this.head(key);if(!f)return null;const {data,error}=await this.admin.storage.from('khushi-media').createSignedUrl(key,60);if(error)throw Error('Media unavailable');const headers=new Headers();const range=options?.range?.get('range');if(range)headers.set('Range',range);const r=await fetch(data.signedUrl,{headers});if(!r.ok)return null;return {body:r.body,size:f.size,range:r.status===206?(()=>{const m=(r.headers.get('content-range')||'').match(/bytes (\d+)-(\d+)/);return m?{offset:+m[1],length:+m[2]-+m[1]+1}:undefined})():undefined,writeHttpMetadata:(h:Headers)=>h.set('Content-Type',f.httpMetadata.contentType)}}
 async delete(key:string){const {error}=await this.admin.storage.from('khushi-media').remove([key]);if(error)throw Error('Media delete failed');await this.db.prepare('DELETE FROM khushi_private.files WHERE key=?').bind(key).run()}
}
