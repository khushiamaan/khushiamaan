import {initialPhotos} from '../../app/server';
const hex=(b:ArrayBuffer)=>Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('');
export async function migrateMedia(req:Request,db:any,admin:any,bucket:any,cfg:any){
 if(!cfg.MIGRATION_KEY||req.headers.get('x-khushi-migration')!==cfg.MIGRATION_KEY||Date.now()>Number(cfg.MIGRATION_EXPIRES))return new Response('Not found',{status:404});
 const source='https://amaan-ki-khushi.honestghost8.chatgpt.site';
 const rows=(await db.prepare("SELECT media FROM records WHERE media<>'' UNION SELECT photo AS media FROM places WHERE photo<>'' UNION SELECT value AS media FROM settings WHERE key IN ('cover','music') AND value<>''").all()).results;
 const paths=[...new Set([...initialPhotos.map(p=>'/photos/'+p[2]),...rows.map((r:any)=>r.media)])] as string[];let copied=0,verified=0;const failures:string[]=[];
 for(const path of paths){
 const seed=initialPhotos.some(p=>path==='/photos/'+p[2]),id=path.split('/').pop()!;if(!seed&&!/^\/api\/media\/[a-f0-9-]{36}$/.test(path)){failures.push('Unsupported reference');continue}
 const key=seed?'seed/'+id:id;
 try{const r=await fetch(source+(seed?path:'/api/migration?media='+id),{headers:{'OAI-Sites-Authorization':'Bearer '+cfg.SOURCE_SITE_TOKEN,'x-khushi-migration':cfg.MIGRATION_KEY},redirect:'error',signal:AbortSignal.timeout(25000)});if(!r.ok)throw Error('Source unavailable');const bytes=new Uint8Array(await r.arrayBuffer());if(bytes.length>52428800||!bytes.length)throw Error('Invalid file size');
 const sha=hex(await crypto.subtle.digest('SHA-256',bytes));const before=await bucket.head(key);if(!before){await bucket.put(key,bytes,{httpMetadata:{contentType:r.headers.get('content-type')?.split(';')[0]||'application/octet-stream'},customMetadata:{name:id}});copied++}
 const {data:blob,error}=await admin.storage.from('khushi-media').download(key);if(error||!blob||hex(await crypto.subtle.digest('SHA-256',await blob.arrayBuffer()))!==sha)throw Error('Copy integrity mismatch');verified++;
 }catch(e){failures.push(path+': '+(e instanceof Error?e.message:'Copy failed'))}
 }
 const result={files:paths.length,copied,verified,failures,complete:verified===paths.length&&failures.length===0};await db.prepare("INSERT INTO khushi_private.config(key,value) VALUES('MIGRATION_STATUS',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(JSON.stringify(result)).run();return Response.json(result)
}
