from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
with ZipFile(root/'public/source-code.zip','w',ZIP_DEFLATED) as z:
 for folder in ['app','android','db','drizzle','tests','scripts','components','hooks','lib','.openai','github-pages','migration']:
  for p in sorted((root/folder).rglob('*')):
   relative=p.relative_to(root)
   if not p.is_file() or any(part in ['build','.gradle','node_modules'] for part in relative.parts):continue
   if p.suffix in ['.apk','.keystore','.png','.jpg','.jpeg'] or p.name in ['google-services.json','local.properties']:continue
   z.write(p,relative)
 for name in ['package.json','pnpm-lock.yaml','pnpm-workspace.yaml','vite.config.ts','next.config.ts','cloudflare-env.d.ts','tsconfig.json','drizzle.config.ts','LICENSE.md','README.md','public/sw.js','public/manifest.webmanifest','public/icon.svg']:
  p=root/name
  if p.is_file():z.write(p,name)
