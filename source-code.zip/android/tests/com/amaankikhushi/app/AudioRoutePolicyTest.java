package com.amaankikhushi.app;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;
import java.lang.reflect.*;
import android.media.AudioDeviceInfo;

public class AudioRoutePolicyTest {
 AudioRoutePolicy.Endpoint ear=new AudioRoutePolicy.Endpoint("1","earpiece","Earpiece"),speaker=new AudioRoutePolicy.Endpoint("2","speaker","Speaker"),usb=new AudioRoutePolicy.Endpoint("3","wired","Type-C"),jack=new AudioRoutePolicy.Endpoint("4","wired","3.5 mm"),bt=new AudioRoutePolicy.Endpoint("5","bluetooth","Earbuds");
 AudioRoutePolicy policy(boolean video){AudioRoutePolicy p=new AudioRoutePolicy();p.start(video);return p;}
 @Test public void usbOverridesBothAudioAndVideoDefault(){for(boolean video:new boolean[]{false,true})assertSame(usb,policy(video).choose(Arrays.asList(speaker,ear,usb,bt)));}
 @Test public void jackOverridesVideoSpeaker(){assertSame(jack,policy(true).choose(Arrays.asList(ear,speaker,jack)));}
 @Test public void earbudsOverrideBothBuiltins(){for(boolean video:new boolean[]{false,true})assertSame(bt,policy(video).choose(Arrays.asList(speaker,ear,bt)));}
 @Test public void hotplugMovesAutomaticRoute(){AudioRoutePolicy p=policy(false);assertSame(ear,p.choose(Arrays.asList(ear,speaker)));assertSame(bt,p.choose(Arrays.asList(ear,speaker,bt)));assertSame(usb,p.choose(Arrays.asList(ear,speaker,bt,usb)));}
 @Test public void manualSpeakerSurvivesHeadsetHotplug(){AudioRoutePolicy p=policy(false);p.select(speaker.id);assertSame(speaker,p.choose(Arrays.asList(ear,speaker,usb,bt)));}
 @Test public void selectedHeadsetRemovalFallsBackPrivately(){AudioRoutePolicy p=policy(true);p.select(bt.id);assertSame(bt,p.choose(Arrays.asList(ear,speaker,bt)));assertSame(ear,p.choose(Arrays.asList(speaker,ear)));assertEquals("auto",p.choice());}
 @Test public void automaticHeadsetRemovalDoesNotBlastVideoOnSpeaker(){AudioRoutePolicy p=policy(true);assertSame(usb,p.choose(Arrays.asList(ear,speaker,usb)));assertSame(ear,p.choose(Arrays.asList(ear,speaker)));}
 @Test public void automaticCanBeRestoredAfterManualSelection(){AudioRoutePolicy p=policy(false);p.select(speaker.id);assertSame(speaker,p.choose(Arrays.asList(ear,speaker,usb)));p.select("auto");assertSame(usb,p.choose(Arrays.asList(ear,speaker,usb)));}
 @Test public void noEarpieceTabletStillHasFallback(){assertSame(speaker,policy(false).choose(Arrays.asList(speaker)));assertNull(policy(false).choose(Collections.emptyList()));}
 @Test public void wiredDeviceTypesIncludeBothJacksAndUsb()throws Exception{Method m=CallAudioRouter.class.getDeclaredMethod("wired",int.class);m.setAccessible(true);for(int t:new int[]{AudioDeviceInfo.TYPE_WIRED_HEADSET,AudioDeviceInfo.TYPE_WIRED_HEADPHONES,AudioDeviceInfo.TYPE_USB_HEADSET,AudioDeviceInfo.TYPE_USB_DEVICE,AudioDeviceInfo.TYPE_USB_ACCESSORY})assertEquals(true,m.invoke(null,t));assertEquals(false,m.invoke(null,AudioDeviceInfo.TYPE_BLUETOOTH_A2DP));}
}
