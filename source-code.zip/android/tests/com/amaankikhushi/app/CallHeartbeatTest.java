package com.amaankikhushi.app;
import org.junit.*;
import static org.junit.Assert.*;
import java.net.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.json.*;

public class CallHeartbeatTest {
 static final String ID="11111111-1111-4111-8111-111111111111";
 static final List<Fake> requests=Collections.synchronizedList(new ArrayList<>());
 static volatile int refreshStatus=200,callStatus=200;
 static volatile CountDownLatch endedRequest;
 static class Fake extends HttpURLConnection {
  ByteArrayOutputStream body=new ByteArrayOutputStream();
  Fake(URL u){super(u);}
  public void connect(){} public void disconnect(){} public boolean usingProxy(){return false;}
  public OutputStream getOutputStream(){return body;}
  public int getResponseCode(){requests.add(this);if(body.toString().contains("\"end\"")&&endedRequest!=null)endedRequest.countDown();return url.getPath().contains("/auth/")?refreshStatus:callStatus;}
  public InputStream getInputStream(){String data=url.getPath().contains("/auth/")?"{\"access_token\":\"fresh-access\",\"refresh_token\":\"fresh-refresh\",\"expires_in\":3600}":"{\"call\":{\"id\":\""+ID+"\",\"state\":\"active\"}}";return new ByteArrayInputStream(data.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
 }
 @BeforeClass public static void network(){URL.setURLStreamHandlerFactory(protocol->protocol.equals("https")?new URLStreamHandler(){protected URLConnection openConnection(URL u){return new Fake(u);}}:null);}
 @Before public void reset(){requests.clear();refreshStatus=200;callStatus=200;endedRequest=null;CallService.onCredentials=null;}
 void ping(CallHeartbeat h)throws Exception{Method m=CallHeartbeat.class.getDeclaredMethod("send",String.class);m.setAccessible(true);m.invoke(h,"ping");}
 void finish(CallHeartbeat h)throws Exception{h.close();Field f=CallHeartbeat.class.getDeclaredField("access");f.setAccessible(true);for(int n=0;n<400;n++){if("".equals(f.get(h)))return;Thread.sleep(10);}fail("End did not clear credentials");}
 @Test public void fixedEndpointAndBearer()throws Exception{
  AtomicInteger ended=new AtomicInteger();CallHeartbeat h=new CallHeartbeat(ID,"old-access","old-refresh",System.currentTimeMillis()/1000+3600,ended::incrementAndGet,false);ping(h);
  assertEquals(1,requests.size());Fake c=requests.get(0);assertEquals("gqcyskripxesrryfunhv.supabase.co",c.getURL().getHost());assertEquals("/functions/v1/khushi-api/api/calls",c.getURL().getPath());assertEquals("Bearer old-access",c.getRequestProperty("Authorization"));assertNull(c.getRequestProperty("Cookie"));assertFalse(c.getInstanceFollowRedirects());assertEquals(0,ended.get());finish(h);
 }
 @Test public void refreshThenSynchronizeAndClear()throws Exception{
  endedRequest=new CountDownLatch(1);AtomicReference<String> synced=new AtomicReference<>();CallService.onCredentials=(a,r,e)->synced.set(a+":"+r);
  CallHeartbeat h=new CallHeartbeat(ID,"expired-access","old-refresh",1,()->fail("Unexpected end"),false);ping(h);
  assertTrue(requests.stream().anyMatch(c->c.getURL().getPath().equals("/auth/v1/token")&&c.body.toString().contains("old-refresh")));
  assertTrue(requests.stream().anyMatch(c->"Bearer fresh-access".equals(c.getRequestProperty("Authorization"))));assertEquals("fresh-access:fresh-refresh",synced.get());finish(h);assertTrue(endedRequest.await(3,TimeUnit.SECONDS));
  for(int n=0;n<100;n++){Field f=CallHeartbeat.class.getDeclaredField("access");f.setAccessible(true);if("".equals(f.get(h)))return;Thread.sleep(10);}fail("Credential not cleared after end");
 }
 @Test public void invalidRefreshEndsCall()throws Exception{refreshStatus=401;AtomicInteger ended=new AtomicInteger();CallHeartbeat h=new CallHeartbeat(ID,"expired","revoked",1,ended::incrementAndGet,false);ping(h);assertEquals(1,ended.get());assertFalse(requests.stream().anyMatch(c->c.getURL().getPath().contains("/functions/")));finish(h);}
 @Test public void redirectEndsCall()throws Exception{callStatus=302;AtomicInteger ended=new AtomicInteger();CallHeartbeat h=new CallHeartbeat(ID,"access","refresh",System.currentTimeMillis()/1000+3600,ended::incrementAndGet,false);ping(h);assertEquals(1,ended.get());assertFalse(requests.get(0).getInstanceFollowRedirects());finish(h);}
}
