# Khushi Forever Android 1.6

Native launcher and origin-restricted WebView for https://khushiamaan.github.io/khushiamaan/.
Package com.amaankikhushi.app, versionCode 7. The existing portrait, entrance design, permissions and audio routing are preserved.

The active call shares its own Supabase session with the non-exported foreground service, in memory only. Native heartbeat uses fixed Supabase HTTPS endpoints, rejects redirects, refreshes near expiry if browser refresh is suspended, and synchronizes rotated tokens back to the web client. Ending the call clears native credentials. Firebase notification registration remains explicit under Phone settings.

GitHub Actions runs isolated web regressions, four native heartbeat unit tests, then compiles and aligns the unsigned release. The original signing keystore remains outside GitHub. Sign locally with official apksigner and verify SHA-256 certificate 3a48a239f4663803d4344ee80739762da4bf7e726292f2f54ddd41c3a3ac2b85 before distributing as an update. Never commit the key.

Actual phone microphone, earpiece/speaker, video, lock-screen continuation, incoming notification and media export require phone testing. STUN-only calling may need a TURN relay on restrictive networks.
