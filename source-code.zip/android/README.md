# Khushi Forever Android launcher
A small signed Android APK that opens the live app in a Chrome Custom Tab, sharing the browser's secure login session. Falls back to another browser if Chrome is absent. It requires internet; it does not embed a WebView, cache photos, or implement a separate login. Android 6+.

Build using JDK 17, Android platform 35 and build-tools 35.0.0. Compile MainActivity.java against android.jar, dex using d8, link resources using aapt2, add classes.dex, zipalign, and apksigner. Keep your signing keystore outside the source repository. This initial APK uses a development signing key and is intended for direct personal testing, not Play Store distribution. Cloud memories are independent of the APK installation.
