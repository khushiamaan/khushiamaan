package com.amaankikhushi.app;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.os.*;

/** Keeps an explicitly started WebView call in a foreground process. No recording. */
public final class CallService extends Service {
 static final String SESSION="com.amaankikhushi.app.CALL_SESSION";
 static final String END="com.amaankikhushi.app.END_CALL",CHANNEL="khushi_active_call";
 static volatile boolean active=false;
 static Runnable onEnd;
 private PowerManager.WakeLock wake;
 private AudioManager audio;
 private CallHeartbeat heartbeat;
 private String callId="";
 private int previousMode;
 private AudioFocusRequest focus;
 @Override public void onCreate(){super.onCreate();audio=getSystemService(AudioManager.class);previousMode=audio.getMode();
  if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Ongoing call",NotificationManager.IMPORTANCE_LOW);c.setSound(null,null);getSystemService(NotificationManager.class).createNotificationChannel(c);}
 }
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  if(intent==null||END.equals(intent.getAction())){if(onEnd!=null)new Handler(getMainLooper()).post(onEnd);stopSelf();return START_NOT_STICKY;}
  if(SESSION.equals(intent.getAction())){
   String id=intent.getStringExtra("call_id"),cookie=intent.getStringExtra("cookie");
   if(active&&id!=null&&id.matches("[a-f0-9-]{36}")&&cookie!=null&&!cookie.isEmpty()&&!id.equals(callId)){
    if(heartbeat!=null)heartbeat.close();callId=id;
    heartbeat=new CallHeartbeat(id,cookie,()->{if(onEnd!=null)new Handler(getMainLooper()).post(onEnd);else stopSelf();});
   }
   return START_NOT_STICKY;
  }
  Intent open=new Intent(this,CallActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
  PendingIntent show=PendingIntent.getActivity(this,303,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  PendingIntent end=PendingIntent.getService(this,304,new Intent(this,CallService.class).setAction(END),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder n=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
  n.setSmallIcon(R.drawable.notification_heart).setContentTitle("Khushi Forever • Call active").setContentText("Mic call ke liye active hai. Tap karke call kholo.").setOngoing(true).setContentIntent(show).setCategory(Notification.CATEGORY_CALL).setVisibility(Notification.VISIBILITY_PRIVATE).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"End call",end).build());
  boolean video=intent.getBooleanExtra("video",false);
  try{
   if(Build.VERSION.SDK_INT>=29)startForeground(303,n.build(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE|(video?ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA:0));else startForeground(303,n.build());
   if(!active){
    AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
    if(Build.VERSION.SDK_INT>=26){focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(attributes).setOnAudioFocusChangeListener(change->{if(change==AudioManager.AUDIOFOCUS_LOSS&&onEnd!=null)new Handler(getMainLooper()).post(onEnd);}).build();audio.requestAudioFocus(focus);}
    audio.setMode(AudioManager.MODE_IN_COMMUNICATION);
    PowerManager pm=getSystemService(PowerManager.class);wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"KhushiForever:Call");wake.acquire(4*60*60*1000L);
   }
   active=true;setRoute(this,video);
  }catch(RuntimeException denied){if(onEnd!=null)new Handler(getMainLooper()).post(onEnd);stopSelf();}
  return START_NOT_STICKY;
 }
 @SuppressWarnings("deprecation") static boolean setRoute(Context context,boolean speaker){
  AudioManager manager=context.getSystemService(AudioManager.class);
  if(!active)return false;
  try{
   if(Build.VERSION.SDK_INT>=31){
    AudioDeviceInfo chosen=null;
    for(AudioDeviceInfo d:manager.getAvailableCommunicationDevices()){
     if(speaker&&d.getType()==AudioDeviceInfo.TYPE_BUILTIN_SPEAKER)chosen=d;
     if(!speaker&&d.getType()==AudioDeviceInfo.TYPE_BUILTIN_EARPIECE)chosen=d;
    }
    return chosen!=null&&manager.setCommunicationDevice(chosen);
   }
   manager.setSpeakerphoneOn(speaker);return manager.isSpeakerphoneOn()==speaker;
  }catch(RuntimeException error){return false;}
 }
 @Override public void onTaskRemoved(Intent root){if(onEnd!=null)new Handler(getMainLooper()).post(onEnd);stopSelf();}
 @Override public void onDestroy(){
  active=false;if(heartbeat!=null){heartbeat.close();heartbeat=null;}callId="";
  if(audio!=null){if(Build.VERSION.SDK_INT>=31)audio.clearCommunicationDevice();else audio.setSpeakerphoneOn(false);if(focus!=null&&Build.VERSION.SDK_INT>=26)audio.abandonAudioFocusRequest(focus);audio.setMode(previousMode);}
  if(wake!=null&&wake.isHeld())wake.release();stopForeground(true);super.onDestroy();
 }
 @Override public IBinder onBind(Intent i){return null;}
}
