package com.amaankikhushi.app;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.os.*;

/** Keeps an explicitly started WebView call in a foreground process. No recording. */
public final class CallService extends Service {
 static final String SESSION="com.amaankikhushi.app.CALL_SESSION";
 static final String END="com.amaankikhushi.app.END_CALL",CHANNEL="khushi_active_call";
 static volatile boolean active=false;
 static Runnable onEnd;
 interface Credentials { void ready(String access,String refresh,long expires); }
 static volatile Credentials onCredentials;
 private static volatile CallHeartbeat currentHeartbeat;
 static void republishCredentials(){CallHeartbeat h=currentHeartbeat;if(h!=null)h.publish();}
 interface AudioRoute { void ready(String label,boolean pending); }
 static volatile AudioRoute onAudioRoute;
 private static volatile CallAudioRouter router;
 static CallAudioRouter audioRouter(){return active?router:null;}
 static void republishAudioRoute(){CallAudioRouter r=router;if(r!=null)r.publish();}
 static boolean autoRoute(){CallAudioRouter r=router;return active&&r!=null&&r.auto();}
 private PowerManager.WakeLock wake;
 private AudioManager audio;
 private CallHeartbeat heartbeat;
 private String callId="";
 private int previousMode;
 private AudioFocusRequest focus;
 @Override public void onCreate(){super.onCreate();audio=getSystemService(AudioManager.class);previousMode=audio.getMode();
  if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Ongoing call",NotificationManager.IMPORTANCE_LOW);c.setSound(null,null);getSystemService(NotificationManager.class).createNotificationChannel(c);}
 }
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  if(intent==null||END.equals(intent.getAction())){if(onEnd!=null)new Handler(getMainLooper()).post(onEnd);stopSelf();return START_NOT_STICKY;}
  if(SESSION.equals(intent.getAction())){
   String id=intent.getStringExtra("call_id"),access=intent.getStringExtra("access"),refresh=intent.getStringExtra("refresh");long expires=intent.getLongExtra("expires",0);
   if(active&&id!=null&&id.matches("[a-f0-9-]{36}")&&access!=null&&refresh!=null&&expires>System.currentTimeMillis()/1000){
    if(!id.equals(callId)){
     if(heartbeat!=null)heartbeat.close();callId=id;
     heartbeat=new CallHeartbeat(id,access,refresh,expires,()->{if(onEnd!=null)new Handler(getMainLooper()).post(onEnd);else stopSelf();});currentHeartbeat=heartbeat;
    }else if(heartbeat!=null)heartbeat.update(access,refresh,expires);
   }
   return START_NOT_STICKY;
  }
  Intent open=new Intent(this,CallActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
  PendingIntent show=PendingIntent.getActivity(this,303,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  PendingIntent end=PendingIntent.getService(this,304,new Intent(this,CallService.class).setAction(END),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder n=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
  n.setSmallIcon(R.drawable.notification_heart).setContentTitle("Khushi Forever • Call active").setContentText("Mic call ke liye active hai. Tap karke call kholo.").setOngoing(true).setContentIntent(show).setCategory(Notification.CATEGORY_CALL).setVisibility(Notification.VISIBILITY_PRIVATE).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"End call",end).build());
  boolean video=intent.getBooleanExtra("video",false);
  try{
   if(Build.VERSION.SDK_INT>=29)startForeground(303,n.build(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE|(video?ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA:0));else startForeground(303,n.build());
   if(!active){
    AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
    if(Build.VERSION.SDK_INT>=26){focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(attributes).setOnAudioFocusChangeListener(change->{if(change==AudioManager.AUDIOFOCUS_LOSS&&onEnd!=null)new Handler(getMainLooper()).post(onEnd);}).build();audio.requestAudioFocus(focus);}
    audio.setMode(AudioManager.MODE_IN_COMMUNICATION);
    PowerManager pm=getSystemService(PowerManager.class);wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"KhushiForever:Call");wake.acquire(4*60*60*1000L);
   }
   active=true;if(router==null)router=new CallAudioRouter(this,audio,video,(label,pending)->{AudioRoute callback=onAudioRoute;if(callback!=null)callback.ready(label,pending);});
  }catch(RuntimeException denied){if(onEnd!=null)new Handler(getMainLooper()).post(onEnd);stopSelf();}
  return START_NOT_STICKY;
 }
 static boolean setRoute(Context context,boolean speaker){CallAudioRouter r=router;return active&&r!=null&&r.builtin(speaker);}
 @Override public void onTaskRemoved(Intent root){if(onEnd!=null)new Handler(getMainLooper()).post(onEnd);stopSelf();}
 @Override public void onDestroy(){
  active=false;if(router!=null){router.close();router=null;}currentHeartbeat=null;if(heartbeat!=null){heartbeat.close();heartbeat=null;}callId="";
  if(audio!=null){if(focus!=null&&Build.VERSION.SDK_INT>=26)audio.abandonAudioFocusRequest(focus);audio.setMode(previousMode);}
  if(wake!=null&&wake.isHeld())wake.release();stopForeground(true);super.onDestroy();
 }
 @Override public IBinder onBind(Intent i){return null;}
}
