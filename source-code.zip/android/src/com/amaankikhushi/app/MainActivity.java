package com.amaankikhushi.app;
import android.app.*;
import android.os.*;
import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.widget.*;
import android.view.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;

/** One entrance action; device setup is available only from the settings gear. */
public final class MainActivity extends Activity {
 private static final String SITE="https://khushiamaan.github.io/khushiamaan/";
 private String token="";
 @Override public void onCreate(Bundle state){super.onCreate(state);FirebaseApp.initializeApp(this);KhushiMessagingService.createChannel(this);
  FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(27,13,22));
  LinearLayout column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);column.setGravity(Gravity.CENTER);column.setPadding(dp(28),dp(64),dp(28),dp(40));
  ImageView portrait=new ImageView(this);portrait.setImageResource(R.drawable.icon);portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);column.addView(portrait,new LinearLayout.LayoutParams(dp(180),dp(180)));
  TextView title=text("Khushi Forever ♡",29,Color.rgb(246,171,163));title.setTypeface(Typeface.create("serif",Typeface.NORMAL));column.addView(title);column.addView(text("Har khushi, tumse.",17,Color.rgb(224,193,205)));
  Button enter=new Button(this);enter.setText("Enter Happiness ♡");enter.setAllCaps(false);enter.setTextColor(Color.rgb(255,224,217));android.graphics.drawable.GradientDrawable shape=new android.graphics.drawable.GradientDrawable();shape.setColor(Color.rgb(77,34,52));shape.setCornerRadius(dp(28));shape.setStroke(dp(1),Color.rgb(170,113,132));enter.setBackground(shape);enter.setPadding(dp(14),dp(12),dp(14),dp(12));enter.setOnClickListener(v->startActivity(new Intent(this,CallActivity.class)));LinearLayout.LayoutParams action=new LinearLayout.LayoutParams(-1,dp(54));action.topMargin=dp(26);column.addView(enter,action);
  column.addView(text("1.6 • Made with love",11,Color.rgb(166,130,150)));
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(column);root.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
  TextView gear=text("⚙",26,Color.rgb(224,193,205));gear.setContentDescription("Phone settings");gear.setClickable(true);gear.setFocusable(true);gear.setOnClickListener(v->showSettings());FrameLayout.LayoutParams settings=new FrameLayout.LayoutParams(dp(52),dp(52),Gravity.TOP|Gravity.END);settings.topMargin=dp(10);settings.rightMargin=dp(12);root.addView(gear,settings);setContentView(root);
  if(Build.VERSION.SDK_INT>=30)root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;});
  refreshToken();if(getIntent().getBooleanExtra("open_call",false))openIncoming();else if(getIntent().getBooleanExtra("open_settings",false))showSettings();
 }
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(intent.getBooleanExtra("open_call",false))openIncoming();else if(intent.getBooleanExtra("open_settings",false))showSettings();}
 private void showSettings(){new AlertDialog.Builder(this).setTitle("Phone settings").setItems(new String[]{"Link this phone for call notifications","Notification permission","Open website in browser","About Khushi Forever"},(dialog,index)->{
  if(index==0){if(token.isEmpty()){refreshToken();Toast.makeText(this,"Internet check karke dobara try karein.",Toast.LENGTH_LONG).show();}else openWebsite(true);}
  else if(index==1){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);else if(Build.VERSION.SDK_INT>=26)startActivity(new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName()));else startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}
  else if(index==2)openWebsite(false);
  else new AlertDialog.Builder(this).setTitle("Khushi Forever ♡").setMessage("Version 1.6\nHar khushi, tumse.\n\nApni yaadein, invite access aur audio/video calls.").setPositiveButton("Close",null).show();
 }).setNegativeButton("Close",null).show();}
 private void openIncoming(){if(getSharedPreferences("khushi",MODE_PRIVATE).getBoolean("native_calls",false))startActivity(new Intent(this,CallActivity.class));else openWebsite(false);}
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(10),0,dp(10));return t;}
 private void refreshToken(){FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{if(task.isSuccessful()){token=task.getResult();getSharedPreferences("khushi",MODE_PRIVATE).edit().putString("fcm_token",token).apply();}});}
 private void openWebsite(boolean link){Uri uri=Uri.parse(SITE);if(link)uri=uri.buildUpon().encodedFragment("kf-device="+Uri.encode(token)).build();Intent open=new Intent(Intent.ACTION_VIEW,uri);Bundle extras=new Bundle();extras.putBinder("android.support.customtabs.extra.SESSION",null);open.putExtras(extras);open.putExtra("android.support.customtabs.extra.TOOLBAR_COLOR",Color.rgb(35,14,25));open.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY",1);open.setPackage("com.android.chrome");try{startActivity(open);}catch(ActivityNotFoundException e){open.setPackage(null);try{startActivity(open);}catch(ActivityNotFoundException missing){Toast.makeText(this,"Pehle Chrome ya doosra browser install karein.",Toast.LENGTH_LONG).show();}}}
}
