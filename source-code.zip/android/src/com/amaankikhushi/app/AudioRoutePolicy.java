package com.amaankikhushi.app;
import java.util.*;

/** Device-independent route decisions, shared by real Android routing and regression tests. */
final class AudioRoutePolicy {
 static final class Endpoint {
  final String id,kind,label;
  Endpoint(String id,String kind,String label){this.id=id;this.kind=kind;this.label=label;}
 }
 private String choice="auto";
 private boolean videoDefault,hadExternal;
 void start(boolean video){choice="auto";videoDefault=video;hadExternal=false;}
 String choice(){return choice;}
 void select(String id){choice=id;}
 Endpoint choose(List<Endpoint> list){
  if(!choice.equals("auto")){
   for(Endpoint e:list)if(e.id.equals(choice))return e;
   // A removed selected accessory must not unexpectedly expose the call on speaker.
   choice="auto";videoDefault=false;
  }
  for(String kind:new String[]{"wired","bluetooth"})for(Endpoint e:list)if(e.kind.equals(kind)){hadExternal=true;return e;}
  if(hadExternal){hadExternal=false;videoDefault=false;}
  for(String kind:new String[]{videoDefault?"speaker":"earpiece","earpiece","speaker"})for(Endpoint e:list)if(e.kind.equals(kind))return e;
  return null;
 }
}
