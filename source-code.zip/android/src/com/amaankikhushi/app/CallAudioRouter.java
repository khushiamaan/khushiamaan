package com.amaankikhushi.app;
import android.Manifest;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.*;
import android.os.*;
import java.util.*;

/** Owns routes only for the lifetime of an explicitly started call. */
@SuppressWarnings("deprecation")
final class CallAudioRouter implements AutoCloseable {
 interface Listener { void changed(String label,boolean pending); }
 private final Context context;
 private final AudioManager manager;
 private final Handler main=new Handler(Looper.getMainLooper());
 private final AudioRoutePolicy policy=new AudioRoutePolicy();
 private final Listener listener;
 private final Map<String,AudioDeviceInfo> devices=new HashMap<>();
 private boolean closed,scoRequested,scoConnected;
 private String requested="",lastLabel="Audio",failedBluetooth="";
 private ModernObserver observer;
 private static final class ModernObserver implements AutoCloseable {
  final AudioManager manager;final AudioManager.OnCommunicationDeviceChangedListener listener;
  ModernObserver(Context c,AudioManager audio,Runnable changed){manager=audio;listener=d->changed.run();manager.addOnCommunicationDeviceChangedListener(c.getMainExecutor(),listener);}
  @Override public void close(){manager.removeOnCommunicationDeviceChangedListener(listener);}
 }
 private final Runnable timeout;
 private final AudioDeviceCallback deviceCallback=new AudioDeviceCallback(){
  @Override public void onAudioDevicesAdded(AudioDeviceInfo[] added){hardwareChanged();}
  @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] removed){hardwareChanged();}
 };
 private final BroadcastReceiver receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){
  if(closed)return;
  if(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED.equals(i.getAction())){
   int state=i.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE,-1);
   if(state==AudioManager.SCO_AUDIO_STATE_CONNECTED&&scoRequested){scoConnected=true;manager.setBluetoothScoOn(true);main.removeCallbacks(timeout);publish();}
   else if(state==AudioManager.SCO_AUDIO_STATE_DISCONNECTED&&scoConnected){scoConnected=false;scoRequested=false;requested="";policy.select("auto");hardwareChanged();}
  }else {failedBluetooth="";hardwareChanged();}
 }};
 CallAudioRouter(Context c,AudioManager audio,boolean video,Listener onChange){
  context=c;manager=audio;listener=onChange;policy.start(video);
  timeout=()->{if(closed)return;failedBluetooth=requested;requested="";stopSco();policy.select("earpiece");apply();listener.changed("Headset connect nahi hua. Audio output se dobara chunein.",false);};
  manager.registerAudioDeviceCallback(deviceCallback,main);
  if(Build.VERSION.SDK_INT>=31){observer=new ModernObserver(context,manager,()->{if(closed)return;AudioDeviceInfo d=manager.getCommunicationDevice();if(d!=null&&String.valueOf(d.getId()).equals(requested))main.removeCallbacks(timeout);publish();});}
  IntentFilter filter=new IntentFilter();filter.addAction(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED);filter.addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED);
  if(Build.VERSION.SDK_INT>=33)context.registerReceiver(receiver,filter,Context.RECEIVER_EXPORTED);else context.registerReceiver(receiver,filter);
  apply();
 }
 static boolean bluetoothPermission(Context c){return Build.VERSION.SDK_INT<31||c.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;}
 static boolean bluetoothAttached(Context c){
  try{for(AudioDeviceInfo d:c.getSystemService(AudioManager.class).getDevices(AudioManager.GET_DEVICES_OUTPUTS))if(bluetooth(d.getType()))return true;}catch(RuntimeException ignored){}
  return false;
 }
 private static boolean wired(int t){return t==AudioDeviceInfo.TYPE_WIRED_HEADSET||t==AudioDeviceInfo.TYPE_WIRED_HEADPHONES||t==AudioDeviceInfo.TYPE_USB_HEADSET||t==AudioDeviceInfo.TYPE_USB_DEVICE||t==AudioDeviceInfo.TYPE_USB_ACCESSORY;}
 private static boolean bluetooth(int t){return t==AudioDeviceInfo.TYPE_BLUETOOTH_SCO||t==AudioDeviceInfo.TYPE_BLUETOOTH_A2DP||t==AudioDeviceInfo.TYPE_BLE_HEADSET||t==AudioDeviceInfo.TYPE_BLE_SPEAKER||t==AudioDeviceInfo.TYPE_HEARING_AID;}
 private String label(AudioDeviceInfo d){int t=d.getType();if(t==AudioDeviceInfo.TYPE_BUILTIN_SPEAKER)return "Speaker";if(t==AudioDeviceInfo.TYPE_BUILTIN_EARPIECE)return "Earpiece";if(wired(t))return t==AudioDeviceInfo.TYPE_WIRED_HEADSET||t==AudioDeviceInfo.TYPE_WIRED_HEADPHONES?"Wired earphones (3.5 mm)":"USB / Type-C earphones";String name=String.valueOf(d.getProductName());return "Bluetooth"+(name.isEmpty()?"":" • "+name.substring(0,Math.min(60,name.length())));}
 List<AudioRoutePolicy.Endpoint> available(){
  List<AudioRoutePolicy.Endpoint> list=new ArrayList<>();devices.clear();
  if(Build.VERSION.SDK_INT>=31){
   for(AudioDeviceInfo d:manager.getAvailableCommunicationDevices()){
    int t=d.getType();String kind=wired(t)?"wired":bluetooth(t)?"bluetooth":t==AudioDeviceInfo.TYPE_BUILTIN_EARPIECE?"earpiece":t==AudioDeviceInfo.TYPE_BUILTIN_SPEAKER?"speaker":"";
    if(kind.isEmpty()||(kind.equals("bluetooth")&&!bluetoothPermission(context)))continue;
    String id=String.valueOf(d.getId());if(id.equals(failedBluetooth))continue;devices.put(id,d);list.add(new AudioRoutePolicy.Endpoint(id,kind,label(d)));
   }
  }else{
   AudioDeviceInfo external=null;boolean hasEarpiece=false;
   for(AudioDeviceInfo d:manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)){if(wired(d.getType()))external=d;if(d.getType()==AudioDeviceInfo.TYPE_BUILTIN_EARPIECE)hasEarpiece=true;}
   if(external!=null)list.add(new AudioRoutePolicy.Endpoint("wired","wired",label(external)));
   try{BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();if(adapter!=null&&adapter.isEnabled()&&adapter.getProfileConnectionState(BluetoothProfile.HEADSET)==BluetoothProfile.STATE_CONNECTED&&manager.isBluetoothScoAvailableOffCall()&&!failedBluetooth.equals("bluetooth"))list.add(new AudioRoutePolicy.Endpoint("bluetooth","bluetooth","Bluetooth headset / earbuds"));}catch(SecurityException ignored){}
   if(hasEarpiece&&external==null)list.add(new AudioRoutePolicy.Endpoint("earpiece","earpiece","Earpiece"));
   list.add(new AudioRoutePolicy.Endpoint("speaker","speaker","Speaker"));
  }
  return list;
 }
 private void hardwareChanged(){if(closed)return;main.removeCallbacks(recheck);main.postDelayed(recheck,350);}
 private final Runnable recheck=()->{if(!closed)apply();};
 boolean select(String id){if(closed)return false;failedBluetooth="";if(id.equals("auto"))policy.select("auto");else{boolean found=false;for(AudioRoutePolicy.Endpoint e:available())if(e.id.equals(id)){found=true;break;}if(!found)return false;policy.select(id);}return apply();}
 boolean auto(){requested="";return select("auto");}
 boolean builtin(boolean speaker){for(AudioRoutePolicy.Endpoint e:available())if(e.kind.equals(speaker?"speaker":"earpiece"))return select(e.id);return false;}
 private boolean apply(){
  if(closed)return false;
  try{AudioRoutePolicy.Endpoint chosen=policy.choose(available());if(chosen==null)return false;
   if(Build.VERSION.SDK_INT>=31){AudioDeviceInfo target=devices.get(chosen.id);AudioDeviceInfo current=manager.getCommunicationDevice();
    if(current!=null&&current.getId()==target.getId()){requested=chosen.id;main.removeCallbacks(timeout);publish();return true;}
    if(chosen.id.equals(requested)){publish();return true;}
    if(!manager.setCommunicationDevice(target))return false;
    requested=chosen.id;main.removeCallbacks(timeout);main.postDelayed(timeout,30000);publish();return true;
   }
   if(chosen.kind.equals("bluetooth")){
    manager.setSpeakerphoneOn(false);
    if(!scoRequested){scoRequested=true;scoConnected=manager.isBluetoothScoOn();manager.startBluetoothSco();manager.setBluetoothScoOn(true);main.removeCallbacks(timeout);main.postDelayed(timeout,15000);}
    requested=chosen.id;
   }else{stopSco();manager.setSpeakerphoneOn(chosen.kind.equals("speaker"));requested=chosen.id;}
   publish();return true;
  }catch(RuntimeException unavailable){listener.changed("Audio output available nahi hai. Dobara chunein.",false);return false;}
 }
 void publish(){if(closed)return;boolean pending=false;String label="Audio";
  try{
   if(Build.VERSION.SDK_INT>=31){AudioDeviceInfo current=manager.getCommunicationDevice();if(current!=null)label=label(current);pending=!requested.isEmpty()&&(current==null||!requested.equals(String.valueOf(current.getId())));}
   else if(scoRequested){label="Bluetooth";pending=!scoConnected;}
   else if(manager.isSpeakerphoneOn())label="Speaker";
   else {label="Earpiece";for(AudioDeviceInfo d:manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS))if(wired(d.getType())){label=label(d);break;}}
  }catch(RuntimeException ignored){}
  lastLabel=label;listener.changed(label,pending);
 }
 String currentLabel(){return lastLabel;}
 private void stopSco(){main.removeCallbacks(timeout);if(Build.VERSION.SDK_INT<31&&(scoRequested||scoConnected)){scoRequested=false;scoConnected=false;try{manager.stopBluetoothSco();manager.setBluetoothScoOn(false);}catch(RuntimeException ignored){}}}
 @Override public void close(){if(closed)return;closed=true;main.removeCallbacksAndMessages(null);try{manager.unregisterAudioDeviceCallback(deviceCallback);}catch(RuntimeException ignored){}try{context.unregisterReceiver(receiver);}catch(RuntimeException ignored){}if(Build.VERSION.SDK_INT>=31){if(observer!=null)observer.close();manager.clearCommunicationDevice();}else{stopSco();manager.setSpeakerphoneOn(false);}}
}
