package com.amaankikhushi.app;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import org.json.*;

/** Active-call credentials stay in memory. TLS endpoints are fixed; redirects are rejected. */
final class CallHeartbeat implements AutoCloseable {
 private static final String BASE="https://gqcyskripxesrryfunhv.supabase.co";
 private static final String KEY="sb_publishable_vtVuJ4IO18-c3uJoRJvnIw_rTMi7jrT";
 private final String callId;
 private String access,refresh;
 private long expires;
 private final Runnable onEnded;
 private final ScheduledExecutorService worker=Executors.newSingleThreadScheduledExecutor();
 private volatile boolean closed;
 CallHeartbeat(String id,String accessToken,String refreshToken,long expiry,Runnable ended){this(id,accessToken,refreshToken,expiry,ended,true);}
 CallHeartbeat(String id,String accessToken,String refreshToken,long expiry,Runnable ended,boolean start){callId=id;access=accessToken;refresh=refreshToken;expires=expiry;onEnded=ended;if(start)worker.scheduleWithFixedDelay(()->send("ping"),0,8,TimeUnit.SECONDS);}
 synchronized void update(String a,String r,long e){if(!closed&&e>=expires){access=a;refresh=r;expires=e;}}
 synchronized void publish(){CallService.Credentials callback=CallService.onCredentials;if(!closed&&callback!=null)callback.ready(access,refresh,expires);}
 private String read(HttpURLConnection c)throws Exception{try(InputStream in=c.getInputStream()){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[2048];int n,total=0;while((n=in.read(buf))!=-1){total+=n;if(total>131072)throw new IOException("Response too large");out.write(buf,0,n);}return out.toString("UTF-8");}}
 private HttpURLConnection post(String path,JSONObject body,String bearer)throws Exception{
  HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(8000);c.setReadTimeout(8000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("apikey",KEY);c.setRequestProperty("Origin","https://khushiamaan.github.io");c.setRequestProperty("Content-Type","application/json");if(bearer!=null)c.setRequestProperty("Authorization","Bearer "+bearer);
  byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}return c;
 }
 private boolean refreshIfNeeded()throws Exception{
  String old; synchronized(this){if(expires>System.currentTimeMillis()/1000+15)return true;old=refresh;}
  HttpURLConnection c=null;
  try{c=post("/auth/v1/token?grant_type=refresh_token",new JSONObject().put("refresh_token",old),null);int code=c.getResponseCode();
   if(code==400||code==401||code==403){synchronized(this){if(!old.equals(refresh))return true;}onEnded.run();return false;}
   if(code!=200)return false;
   JSONObject d=new JSONObject(read(c));String a=d.getString("access_token"),r=d.getString("refresh_token");long e=d.optLong("expires_at",System.currentTimeMillis()/1000+d.getLong("expires_in"));
   synchronized(this){if(closed)return false;if(old.equals(refresh)){access=a;refresh=r;expires=e;}}publish();return true;
  }finally{if(c!=null)c.disconnect();}
 }
 private void send(String action){
  if(closed&&!action.equals("end"))return;HttpURLConnection c=null;
  try{if(!refreshIfNeeded())return;String bearer;synchronized(this){bearer=access;}
   c=post("/functions/v1/khushi-api/api/calls",new JSONObject().put("action",action).put("id",callId),bearer);int code=c.getResponseCode();
   if(!action.equals("end")&&!closed){boolean ended=code==401||code==403||code==410||(code>=300&&code<400);if(code==200){JSONObject d=new JSONObject(read(c));JSONObject call=d.optJSONObject("call");ended=call==null||!callId.equals(call.optString("id"))||"ended".equals(call.optString("state"));}if(ended&&!closed)onEnded.run();}
  }catch(Exception transientFailure){/* Retry next heartbeat. Never log credential/error bodies. */}
  finally{if(c!=null)c.disconnect();if(action.equals("end")){synchronized(this){access="";refresh="";expires=0;}}}
 }
 @Override public void close(){if(closed)return;closed=true;worker.shutdownNow();Thread end=new Thread(()->send("end"),"KhushiCallEnd");end.setDaemon(true);end.start();}
}
