package com.amaankikhushi.app;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import org.json.*;

/** Uses the user's own WebView session, only against the exact Site; never stores/logs cookies. */
final class CallHeartbeat implements AutoCloseable {
 private static final String ENDPOINT="https://amaan-ki-khushi.honestghost8.chatgpt.site/api/calls";
 private final String callId,cookie;
 private final Runnable onEnded;
 private final ScheduledExecutorService worker=Executors.newSingleThreadScheduledExecutor();
 private volatile boolean closed;
 CallHeartbeat(String id,String sessionCookie,Runnable ended){callId=id;cookie=sessionCookie;onEnded=ended;worker.scheduleWithFixedDelay(()->send("ping"),0,8,TimeUnit.SECONDS);}
 private void send(String action){
  if(closed&&!action.equals("end"))return;
  HttpURLConnection connection=null;
  try{
   connection=(HttpURLConnection)new URL(ENDPOINT).openConnection();connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(8000);connection.setReadTimeout(8000);connection.setRequestMethod("POST");connection.setDoOutput(true);
   connection.setRequestProperty("Cookie",cookie);connection.setRequestProperty("Origin","https://amaan-ki-khushi.honestghost8.chatgpt.site");connection.setRequestProperty("Sec-Fetch-Site","same-origin");connection.setRequestProperty("Content-Type","application/json");
   byte[] body=new JSONObject().put("action",action).put("id",callId).toString().getBytes(StandardCharsets.UTF_8);connection.setFixedLengthStreamingMode(body.length);try(OutputStream out=connection.getOutputStream()){out.write(body);}
   int code=connection.getResponseCode();
   if(!action.equals("end")&&!closed){
    boolean ended=code==401||code==403||code==410||(code>=300&&code<400);
    if(code==200){try(InputStream in=connection.getInputStream()){ByteArrayOutputStream output=new ByteArrayOutputStream();byte[] bytes=new byte[2048];int count,total=0;while((count=in.read(bytes))!=-1){total+=count;if(total>131072)throw new IOException("Response too large");output.write(bytes,0,count);}JSONObject result=new JSONObject(output.toString("UTF-8"));JSONObject call=result.optJSONObject("call");ended=call==null||!callId.equals(call.optString("id"))||"ended".equals(call.optString("state"));}}
    if(ended&&!closed)onEnded.run();
   }
  }catch(Exception transientNetworkFailure){/* The next heartbeat retries; no credential/error-body logging. */}
  finally{if(connection!=null)connection.disconnect();}
 }
 @Override public void close(){if(closed)return;closed=true;worker.shutdownNow();Thread end=new Thread(()->send("end"),"KhushiCallEnd");end.setDaemon(true);end.start();}
}
