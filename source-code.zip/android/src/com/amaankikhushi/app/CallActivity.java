package com.amaankikhushi.app;
import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.webkit.*;
import java.util.*;
import org.json.*;

/** Isolated WebView login; privileged bridge is injected only into our exact Site origin. */
public final class CallActivity extends Activity {
 private static final String ORIGIN="https://khushiamaan.github.io";
 private WebView web;
 private TextView hint;
 private PermissionRequest pendingMedia;
 private Runnable pendingPrepare;
 private Runnable pendingDenied;
 private Runnable pendingBluetooth;
 private boolean bluetoothAsked;
 private AlertDialog audioDialog;
 private android.webkit.ValueCallback<Uri[]> upload;
 private boolean visible=false;
 private final Handler main=new Handler(Looper.getMainLooper());
 @Override public void onCreate(Bundle state){super.onCreate(state);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(27,13,22));
  hint=new TextView(this);hint.setTextColor(Color.rgb(246,171,163));hint.setTextSize(12);hint.setPadding(16,8,16,8);hint.setText("Khushi Forever ♡ • Apne invited account se sign in karein.");
  web=new WebView(this);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)){
   WebViewCompat.addWebMessageListener(web,"KhushiNative",Collections.singleton(ORIGIN),(view,msg,origin,mainFrame,reply)->{
    if(!mainFrame||!ORIGIN.equals(origin.toString())||!samePage()||msg.getData()==null||msg.getData().length()>32768)return;
    try{JSONObject d=new JSONObject(msg.getData());String id=d.optString("id");String action=d.optString("action");
     if(action.equals("prepare"))prepare(d.optBoolean("video"),()->reply.postMessage(json(id,true,"App audio ready")),()->reply.postMessage(json(id,false,"Mic/camera permission ya foreground service allow nahi hui.")));
     else if(action.equals("session")){
      String callId=d.optString("callId"),access=d.optString("accessToken"),refresh=d.optString("refreshToken");long expires=d.optLong("expiresAt");
      boolean ok=CallService.active&&callId.matches("[a-f0-9-]{36}")&&access.matches("[A-Za-z0-9_.-]{100,12000}")&&refresh.matches("[A-Za-z0-9_.-]{10,4096}")&&expires>System.currentTimeMillis()/1000;
      if(ok)startService(new Intent(this,CallService.class).setAction(CallService.SESSION).putExtra("call_id",callId).putExtra("access",access).putExtra("refresh",refresh).putExtra("expires",expires));
      reply.postMessage(json(id,ok,ok?"Background heartbeat ready":"Call session nahi mili."));
     }
     else if(action.equals("settings")){
      if(CallService.active){reply.postMessage(json(id,false,"Pehle call end karein."));return;}
      reply.postMessage(json(id,true,"Settings"));startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("open_settings",true));
     }
     else if(action.equals("route")){
      if(d.optBoolean("picker"))showAudioRoutes(id,reply);
      else{boolean ok=d.optString("mode").equals("auto")?CallService.autoRoute():CallService.setRoute(this,d.optBoolean("speaker"));reply.postMessage(audioReply(id,ok,ok?"Audio route ready":"Yeh output available nahi hai."));}
     }
     else if(action.equals("end")){pendingPrepare=null;pendingDenied=null;stopService(new Intent(this,CallService.class));setVolumeControlStream(android.media.AudioManager.USE_DEFAULT_STREAM_TYPE);hint.setText("Call end • microphone service stopped");reply.postMessage(json(id,true,"Call stopped"));}
    }catch(JSONException invalid){}
   });
  }else hint.setText("Android System WebView update karein; native call bridge available nahi hai.");
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){String scheme=r.getUrl().getScheme();if("https".equals(scheme))return false;return true;}
   @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon){if((!sameOrigin(Uri.parse(url))||!Uri.parse(url).getPath().startsWith("/khushiamaan/"))&&CallService.active)endCall();}
   @Override public void onPageFinished(WebView v,String url){CookieManager.getInstance().flush();if(sameOrigin(Uri.parse(url))&&!CallService.active)hint.setText("Khushi Forever ♡ • Har khushi, tumse.");}
  });
  web.setDownloadListener((downloadUrl,userAgent,disposition,mime,length)->{Uri u=Uri.parse(downloadUrl);if("https".equals(u.getScheme())&&"gqcyskripxesrryfunhv.supabase.co".equals(u.getHost())&&(u.getPort()==-1||u.getPort()==443)&&u.getPath()!=null&&u.getPath().startsWith("/storage/v1/object/sign/khushi-releases/")){try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(ActivityNotFoundException ignored){Toast.makeText(this,"Download ke liye browser install karein.",Toast.LENGTH_LONG).show();}}});
  web.setWebChromeClient(new WebChromeClient(){
   @Override public void onPermissionRequest(PermissionRequest request){runOnUiThread(()->{
    if(!sameOrigin(request.getOrigin())||!sameOrigin(Uri.parse(web.getUrl()==null?"":web.getUrl()))||!visible){request.deny();return;}
    ArrayList<String> missing=new ArrayList<>();for(String resource:request.getResources()){
     String permission=resource.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE)?Manifest.permission.RECORD_AUDIO:resource.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)?Manifest.permission.CAMERA:null;
     if(permission==null){request.deny();return;}if(checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED)missing.add(permission);
    }
    if(missing.isEmpty())request.grant(request.getResources());else{if(pendingMedia!=null)pendingMedia.deny();pendingMedia=request;requestPermissions(missing.toArray(new String[0]),21);}
   });}
   @Override public void onPermissionRequestCanceled(PermissionRequest request){if(pendingMedia==request)pendingMedia=null;}
   @Override public boolean onShowFileChooser(WebView v,android.webkit.ValueCallback<Uri[]> callback,FileChooserParams params){if(upload!=null)upload.onReceiveValue(null);upload=callback;try{startActivityForResult(params.createIntent(),22);}catch(ActivityNotFoundException e){upload=null;callback.onReceiveValue(null);}return true;}
  });
  CallService.onEnd=()->{endCall();};root.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
  if(Build.VERSION.SDK_INT>=30)root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;});
  CallService.onAudioRoute=(label,pending)->main.post(()->{if(web!=null&&samePage()){try{String detail=new JSONObject().put("route",label).put("pending",pending).toString();web.evaluateJavascript("window.dispatchEvent(new CustomEvent('khushi-audio-route',{detail:"+detail+"}))",null);}catch(JSONException ignored){}}});
  CallService.onCredentials=(access,refresh,expires)->main.post(()->{if(web!=null&&samePage()){try{String detail=new JSONObject().put("access_token",access).put("refresh_token",refresh).put("expires_at",expires).toString();web.evaluateJavascript("window.dispatchEvent(new CustomEvent('khushi-auth-refreshed',{detail:"+detail+"}))",null);}catch(JSONException ignored){}}});
  web.loadUrl(ORIGIN+"/khushiamaan/?app=1.7");
 }
 private boolean sameOrigin(Uri uri){return "https".equals(uri.getScheme())&&"khushiamaan.github.io".equals(uri.getHost())&&(uri.getPort()==-1||uri.getPort()==443);}
 private boolean samePage(){if(web==null||web.getUrl()==null)return false;Uri u=Uri.parse(web.getUrl());return sameOrigin(u)&&u.getPath()!=null&&u.getPath().startsWith("/khushiamaan/");}
 private void add(LinearLayout p,String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextSize(12);b.setAllCaps(false);b.setOnClickListener(v->action.run());p.addView(b,new LinearLayout.LayoutParams(0,-2,1));}
 private void route(boolean speaker){boolean ok=CallService.setRoute(this,speaker);hint.setText(ok?(speaker?"Speaker selected":"Earpiece selected"):"Call shuru hone ke baad route chunein; device par output available hona chahiye.");}
 private static String json(String id,boolean ok,String note){try{return new JSONObject().put("id",id).put("ok",ok).put("message",note).toString();}catch(JSONException ignored){return "{}";}}
 private void prepare(boolean video,Runnable done,Runnable denied){
  if(!visible){denied.run();return;}
  ArrayList<String> permissions=new ArrayList<>();if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)permissions.add(Manifest.permission.RECORD_AUDIO);if(video&&checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)permissions.add(Manifest.permission.CAMERA);
  if(!permissions.isEmpty()){pendingPrepare=()->prepare(video,done,denied);pendingDenied=denied;requestPermissions(permissions.toArray(new String[0]),20);return;}
  if(Build.VERSION.SDK_INT>=31&&!CallAudioRouter.bluetoothPermission(this)&&CallAudioRouter.bluetoothAttached(this)&&!bluetoothAsked){bluetoothAsked=true;pendingBluetooth=()->prepare(video,done,denied);requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},23);return;}
  try{Intent service=new Intent(this,CallService.class).putExtra("video",video);if(Build.VERSION.SDK_INT>=26)startForegroundService(service);else startService(service);
   main.postDelayed(()->{if(CallService.active){getSharedPreferences("khushi",MODE_PRIVATE).edit().putBoolean("native_calls",true).apply();setVolumeControlStream(android.media.AudioManager.STREAM_VOICE_CALL);hint.setText("Call audio • connected earphones ko priority");done.run();}else denied.run();},400);
  }catch(RuntimeException error){denied.run();}
 }
 private String audioReply(String id,boolean ok,String note){try{CallAudioRouter r=CallService.audioRouter();return new JSONObject().put("id",id).put("ok",ok).put("message",note).put("route",r==null?"Audio":r.currentLabel()).toString();}catch(JSONException ignored){return json(id,ok,note);}}
 private void showAudioRoutes(String id,JavaScriptReplyProxy reply){
  CallAudioRouter r=CallService.audioRouter();if(r==null||!visible){reply.postMessage(json(id,false,"Call active nahi hai."));return;}
  if(audioDialog!=null&&audioDialog.isShowing()){reply.postMessage(audioReply(id,true,"Audio picker already open"));return;}
  final java.util.List<AudioRoutePolicy.Endpoint> endpoints=r.available();String[] labels=new String[endpoints.size()+1];labels[0]="Automatic • connected earphones first";for(int n=0;n<endpoints.size();n++)labels[n+1]=endpoints.get(n).label;
  AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("Call audio • "+r.currentLabel()).setItems(labels,(dialog,index)->{boolean ok=CallService.active&&r.select(index==0?"auto":endpoints.get(index-1).id);reply.postMessage(audioReply(id,ok,ok?"Audio output selected":"Device available nahi hai. Dobara chunein."));}).setNegativeButton("Close",(d,w)->reply.postMessage(audioReply(id,true,"Audio unchanged"))).setOnCancelListener(d->reply.postMessage(audioReply(id,true,"Audio unchanged")));
  if(Build.VERSION.SDK_INT>=31&&!CallAudioRouter.bluetoothPermission(this))b.setPositiveButton("Allow Bluetooth",(d,w)->{pendingBluetooth=()->showAudioRoutes(id,reply);requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},23);});
  audioDialog=b.create();audioDialog.show();
 }
 private void endCall(){setVolumeControlStream(android.media.AudioManager.USE_DEFAULT_STREAM_TYPE);if(web!=null)web.evaluateJavascript("window.dispatchEvent(new Event('khushi-native-end'))",null);stopService(new Intent(this,CallService.class));}
 @Override public void onRequestPermissionsResult(int code,String[] names,int[] results){super.onRequestPermissionsResult(code,names,results);boolean ok=results.length>0;for(int r:results)ok&=r==PackageManager.PERMISSION_GRANTED;
  if(code==23){Runnable next=pendingBluetooth;pendingBluetooth=null;if(next!=null&&visible)next.run();CallService.autoRoute();}
  if(code==20){Runnable next=pendingPrepare;Runnable rejected=pendingDenied;pendingPrepare=null;pendingDenied=null;if(ok&&next!=null)next.run();else if(rejected!=null)rejected.run();}
  if(code==21&&pendingMedia!=null){PermissionRequest req=pendingMedia;pendingMedia=null;if(ok&&visible)req.grant(req.getResources());else req.deny();}
 }
 @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(r==22&&upload!=null){upload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));upload=null;}}
 @Override protected void onResume(){super.onResume();visible=true;if(web!=null){web.onResume();CallService.republishCredentials();CallService.republishAudioRoute();}}
 @Override protected void onPause(){visible=false;if(web!=null&&!CallService.active)web.onPause();super.onPause();}
 @Override public void onBackPressed(){if(CallService.active){new AlertDialog.Builder(this).setMessage("Call end karke app call screen band karein?").setPositiveButton("End call",(d,w)->{endCall();finish();}).setNegativeButton("Wapas",null).show();}else if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){CallService.onEnd=null;CallService.onCredentials=null;CallService.onAudioRoute=null;pendingBluetooth=null;if(audioDialog!=null)audioDialog.dismiss();endCall();main.removeCallbacksAndMessages(null);if(pendingMedia!=null)pendingMedia.deny();if(upload!=null)upload.onReceiveValue(null);if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
