package com.amaankikhushi.app;
import android.app.*;
import android.content.*;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

/** Receives notification messages; this service does not capture camera or microphone. */
public final class KhushiMessagingService extends FirebaseMessagingService {
 public static final String CHANNEL="khushi_calls";
 public static void createChannel(Context context){
  if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=new NotificationChannel(CHANNEL,"Incoming calls",NotificationManager.IMPORTANCE_HIGH);channel.setDescription("Khushi Forever incoming call notifications");channel.enableVibration(true);channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build());context.getSystemService(NotificationManager.class).createNotificationChannel(channel);}
 }
 @Override public void onNewToken(String token){getSharedPreferences("khushi",MODE_PRIVATE).edit().putString("fcm_token",token).putBoolean("needs_link",true).apply();}
 @Override public void onMessageReceived(RemoteMessage message){
  createChannel(this);
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
  Map<String,String> data=message.getData();String id=data.get("call_id");boolean incoming="incoming_call".equals(data.get("kind"));
  if(incoming&&(id==null||!id.matches("[a-f0-9-]{36}")))return;
  if(incoming){try{long time=Long.parseLong(data.getOrDefault("created","0"));if(Math.abs(System.currentTimeMillis()/1000-time)>90)return;}catch(NumberFormatException invalid){return;}}
  String title=incoming?"Khushi Forever • Incoming call":"Khushi Forever";
  String body=incoming?("video".equals(data.get("mode"))?"Tumhare liye video call hai ♡":"Tumhare liye audio call hai ♡"):"Ek pyaara sa message aaya hai.";
  if(!incoming&&message.getNotification()!=null){if(message.getNotification().getTitle()!=null)title=message.getNotification().getTitle();if(message.getNotification().getBody()!=null)body=message.getNotification().getBody();}
  Intent intent=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);if(incoming)intent.putExtra("open_call",true);
  int notificationId=incoming?id.hashCode():100;
  PendingIntent pending=PendingIntent.getActivity(this,notificationId,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
  builder.setSmallIcon(R.drawable.notification_heart).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setContentIntent(pending).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).setPriority(Notification.PRIORITY_HIGH).setCategory(incoming?Notification.CATEGORY_CALL:Notification.CATEGORY_MESSAGE);
  if(incoming){builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_call,"Open call",pending).build());if(Build.VERSION.SDK_INT>=26)builder.setTimeoutAfter(60000);}
  getSystemService(NotificationManager.class).notify(notificationId,builder.build());
 }
}
