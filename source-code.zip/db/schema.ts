import { sqliteTable, text, integer, primaryKey } from 'drizzle-orm/sqlite-core';
export const records = sqliteTable('records', {
  id: text('id').primaryKey(), type: text('type').notNull(), title: text('title').notNull(),
  body: text('body').notNull().default(''), date: text('date').notNull().default(''),
  media: text('media').notNull().default(''), mime: text('mime').notNull().default(''),
  done: integer('done').notNull().default(0), created: text('created').notNull(),
});
export const settings = sqliteTable('settings', { key: text('key').primaryKey(), value: text('value').notNull() });
export const editors = sqliteTable('editors', { email: text('email').primaryKey() });
export const hearts = sqliteTable('hearts', { record: text('record').notNull(), user: text('user').notNull() }, t => [primaryKey({columns:[t.record,t.user]})]);
export const calls = sqliteTable('calls', {
 slot: text('slot').primaryKey(), id:text('id').notNull(), caller:text('caller').notNull(), callee:text('callee').notNull(),
 mode:text('mode').notNull(), offer:text('offer').notNull(), answer:text('answer').notNull().default(''),
 state:text('state').notNull(), created:integer('created').notNull(), callerSeen:integer('caller_seen').notNull(), calleeSeen:integer('callee_seen').notNull().default(0),
});
export const devices = sqliteTable('devices', {
 id:text('id').primaryKey(), email:text('email').notNull(), token:text('token').notNull(),
 nickname:text('nickname').notNull().default('Android phone'), created:integer('created').notNull(),
});
export const accessRequests = sqliteTable('access_requests', {
 email:text('email').primaryKey(), role:text('role').notNull(), created:integer('created').notNull(),
});
export const places = sqliteTable('places', {
 id:text('id').primaryKey(), title:text('title').notNull(), story:text('story').notNull().default(''),
 date:text('date').notNull().default(''), photo:text('photo').notNull().default(''),
 mapUrl:text('map_url').notNull().default(''), latitude:text('latitude').notNull().default(''), longitude:text('longitude').notNull().default(''),
 created:integer('created').notNull(), updated:integer('updated').notNull(),
});
