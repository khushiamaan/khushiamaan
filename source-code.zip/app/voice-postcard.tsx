'use client';
import {apiFetch,mediaUrl,sitePath,portable} from './client-api';
import {useEffect,useRef,useState} from 'react';
import {Mic,Square,Trash2,Heart,LoaderCircle} from 'lucide-react';
import {captureVoice,voiceFile,VOICE_LIMIT_SECONDS} from './voice-recorder';
export default function VoicePostcard({callBusy,onSaved}:{callBusy:boolean,onSaved:()=>Promise<void>}) {
 const [open,setOpen]=useState(false),[phase,setPhase]=useState('idle'),[blob,setBlob]=useState<Blob|null>(null),[url,setUrl]=useState(''),[title,setTitle]=useState('Tumhare liye, meri awaaz'),[body,setBody]=useState(''),[elapsed,setElapsed]=useState(0),[message,setMessage]=useState('');
 const capture=useRef<ReturnType<typeof captureVoice>|null>(null),generation=useRef(0),mounted=useRef(true),pending=useRef(false),savingRef=useRef(false),upload=useRef<{media:string,mime:string}|null>(null);
 const recording=phase==='recording'||phase==='permission',saving=phase==='saving';
 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;generation.current++;capture.current?.stop(true)}},[]);
 useEffect(()=>{if(!blob){setUrl('');return}const u=URL.createObjectURL(blob);setUrl(u);return()=>URL.revokeObjectURL(u)},[blob]);
 useEffect(()=>{if(phase!=='recording')return;const start=Date.now();const t=setInterval(()=>setElapsed(Math.min(VOICE_LIMIT_SECONDS,Math.floor((Date.now()-start)/1000))),250);return()=>clearInterval(t)},[phase]);
 useEffect(()=>{const interrupt=()=>{if(document.hidden){generation.current++;capture.current?.stop();if(phase==='permission')setPhase('idle')}};document.addEventListener('visibilitychange',interrupt);return()=>document.removeEventListener('visibilitychange',interrupt)},[phase]);
 useEffect(()=>{if(callBusy){generation.current++;capture.current?.stop();if(phase==='permission')setPhase('idle');setMessage('Call ke baad apna postcard record karein.')}},[callBusy]);
 function discard(){generation.current++;capture.current?.stop(true);capture.current=null;upload.current=null;setBlob(null);setElapsed(0);setPhase('idle');setMessage('')}
 async function record(){if(pending.current||callBusy||saving)return;pending.current=true;const id=++generation.current;setMessage('');setPhase('permission');
 try{if(!navigator.mediaDevices?.getUserMedia||typeof MediaRecorder==='undefined')throw new Error('Is browser mein recording available nahi. Love note mein audio file upload kar sakte hain.');
 const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});
 if(!mounted.current||id!==generation.current){stream.getTracks().forEach(t=>t.stop());return}
 setBlob(null);upload.current=null;setElapsed(0);
 capture.current=captureVoice(stream,MediaRecorder,(b,error)=>{if(!mounted.current)return;capture.current=null;if(error){setMessage(error);setPhase('idle');return}try{if(b)voiceFile(b);setBlob(b);setPhase(b?'preview':'idle');setMessage('Recording sirf Save dabane par share hogi.')}catch(e){setMessage((e as Error).message);setPhase('idle')}});setPhase('recording');
 }catch(e){if(mounted.current&&id===generation.current){setPhase('idle');setMessage(e instanceof DOMException&&e.name==='NotAllowedError'?'Mic permission allow karein. Recording apne aap shuru nahi hoti.':(e as Error).message)}}finally{pending.current=false}}
 async function save(){if(!blob||!title.trim()||savingRef.current)return;savingRef.current=true;setPhase('saving');setMessage('');
 try{if(!upload.current){const fd=new FormData();fd.append('file',voiceFile(blob));const r=await apiFetch('/api/upload',{method:'POST',body:fd});if(!r.ok)throw new Error(await r.text());upload.current=await r.json()}
 const r=await apiFetch('/api/records',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'note',title:title.trim(),body,date:new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()),...upload.current})});if(!r.ok)throw new Error(await r.text());
 // Clear the draft after successful persistence, even if refreshing the list fails.
 discard();setMessage('Voice postcard save ho gaya ♡');await onSaved();
 }catch(e){setPhase('preview');setMessage((e as Error).message.slice(0,220))}finally{savingRef.current=false}}
 return <div className="settings-card voice-postcard"><button className="text-link" disabled={saving} aria-expanded={open} onClick={()=>{if(recording){discard()}setOpen(!open)}}><Mic size={18}/> Voice postcard {open?'band karein':'record karein'}</button>{open&&<><h2>Apni awaaz, pyaar ke saath</h2><p>2 minute tak ka message. Save karne ke baad sab invited guests ise sun sakenge.</p><label>Postcard ka naam<input maxLength={150} value={title} disabled={saving} onChange={e=>setTitle(e.target.value)}/></label><label>Chhota sa message<textarea maxLength={4000} value={body} disabled={saving} onChange={e=>setBody(e.target.value)}/></label><div className="voice-actions">{phase==='recording'?<button className="primary" onClick={()=>capture.current?.stop()}><Square size={16}/> Stop · {elapsed}s / 120s</button>:<button className="outline" disabled={recording||saving||callBusy} onClick={record}>{phase==='permission'?<LoaderCircle className="spin" size={16}/>:<Mic size={16}/>} {blob?'Dobara record karein':'Record shuru karein'}</button>}{(recording||blob)&&<button className="outline" disabled={saving} onClick={discard}><Trash2 size={16}/> Discard</button>}</div>{url&&<audio src={url} controls preload="metadata" aria-label="Voice postcard preview"/>}{blob&&<button className="primary" disabled={saving||recording||!title.trim()} onClick={save}>{saving?<LoaderCircle size={16} className="spin"/>:<Heart size={16}/>} Save voice postcard</button>}<p role="status" aria-live="polite">{message}</p></>}</div>
}
