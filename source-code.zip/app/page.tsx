import CoupleApp from './couple-app';
export const dynamic='force-dynamic';
export default function Page(){return <CoupleApp/>}
