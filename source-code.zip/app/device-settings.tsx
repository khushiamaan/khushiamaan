'use client';
import {apiFetch,mediaUrl,sitePath,portable} from './client-api';
import {useEffect,useState} from 'react';
import {hasNativeAudio,nativeAudio} from './native-audio';
import {Bell,Trash2,RefreshCw} from 'lucide-react';
export default function DeviceSettings(){
 const [data,setData]=useState<{devices:{id:string,nickname:string,created:number}[],pushConfigured:boolean}|null>(null),[error,setError]=useState(''),[native,setNative]=useState(false);
 async function load(){try{const r=await apiFetch('/api/devices');if(!r.ok)throw new Error('Phone settings load nahi hui.');setData(await r.json());setError('')}catch(e:any){setError(e.message)}}
 useEffect(()=>{load();setNative(hasNativeAudio())},[]);
 return <div className="settings-card"><Bell/><h2>Phone notifications</h2>{native&&<button className="outline" onClick={()=>nativeAudio('settings').catch(e=>setError(e.message))}>Phone settings kholo</button>}<p>App ki ⚙️ Phone settings se apne phone ko call notifications ke liye link karein.</p>{data&&<><div className="access-status">{data.pushConfigured?'Call notifications ready':'Call notifications ka setup baaki hai'}</div>{data.devices.length===0?<p className="hint">Is account se abhi koi phone linked nahi hai.</p>:data.devices.map(d=><div className="editor-row" key={d.id}><span>{d.nickname}<small style={{display:'block',fontSize:9,marginTop:6}}>Linked {new Date(d.created).toLocaleDateString('en-IN')}</small></span><button className="icon-btn" title="Unlink phone" aria-label="Unlink phone" onClick={async()=>{try{const r=await apiFetch('/api/devices',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:d.id})});if(!r.ok)throw new Error('Phone unlink nahi hua.');await load()}catch(e:any){setError(e.message)}}}><Trash2 size={17}/></button></div>)}</>}{error&&<p role="alert">{error}</p>}<button className="text-link" onClick={load}><RefreshCw size={14}/> Refresh status</button><p className="hint">Call notifications ke liye app ki notification permission aur internet on rakhein. Phone ki Settings se Force stop karne par app dobara kholni padti hai.</p></div>
}
