/** Origin-restricted Android WebView bridge. Normal browser calls remain unchanged. */
type Reply={id:string,ok:boolean,message:string};
let serial=0;
const pending=new Map<string,{resolve:(r:Reply)=>void,reject:(e:Error)=>void,timer:ReturnType<typeof setTimeout>}>();
let listening=false;
let callId="";
export function nativeCallId(){return callId}
export function hasNativeAudio(){return typeof window!=='undefined'&&typeof (window as any).KhushiNative?.postMessage==='function'}
export function nativeAudio(action:'prepare'|'route'|'end'|'session'|'settings',options:{video?:boolean,speaker?:boolean,callId?:string,accessToken?:string,refreshToken?:string,expiresAt?:number}={}):Promise<Reply>{
 if(!hasNativeAudio())return Promise.resolve({id:'browser',ok:true,message:'Browser audio'});
 if(action==='end')callId='';
 const bridge=(window as any).KhushiNative;
 if(!listening){bridge.onmessage=(event:MessageEvent)=>{try{const r=JSON.parse(event.data) as Reply;const p=pending.get(r.id);if(!p)return;clearTimeout(p.timer);pending.delete(r.id);if(r.ok)p.resolve(r);else p.reject(new Error(r.message||'App audio ready nahi hua.'));}catch{}};listening=true;}
 const id=String(++serial);
 return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(new Error('App audio permission ka response nahi mila. Call end karke dobara try karein.'));},45000);pending.set(id,{resolve:r=>{if(action==='session')callId=options.callId||'';resolve(r)},reject,timer});try{bridge.postMessage(JSON.stringify({id,action,...options}));}catch(e){clearTimeout(timer);pending.delete(id);reject(e);}});
}
