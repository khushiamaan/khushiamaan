import {bucket,identity,fail} from '../../../server';
export const dynamic='force-dynamic';
export async function GET(req:Request,{params}:{params:Promise<{id:string}>}){try{await identity();const{id}=await params;if(!/^[a-f0-9-]{36}$/.test(id))return new Response('Not found',{status:404});
 const object=await bucket().get(id,{range:req.headers});if(!object)return new Response('Not found',{status:404});const headers=new Headers();object.writeHttpMetadata(headers);headers.set('X-Content-Type-Options','nosniff');headers.set('Cache-Control','private, no-store');headers.set('Accept-Ranges','bytes');
 const range=req.headers.has('Range')?object.range:undefined;if(range&&'offset'in range&&range.offset!==undefined&&range.length!==undefined){headers.set('Content-Range',`bytes ${range.offset}-${range.offset+range.length-1}/${object.size}`);headers.set('Content-Length',String(range.length));}else headers.set('Content-Length',String(object.size));
 return new Response(object.body,{status:range?206:200,headers});}catch(e){return fail(e)}}
