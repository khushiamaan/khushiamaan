import {env} from 'cloudflare:workers';
import {bucket} from '../../server';
export const dynamic='force-dynamic';
// Temporary, read-only server-to-server export. Disabled when its runtime key is removed.
export async function GET(req:Request){const expected=(env as any).MIGRATION_EXPORT_KEY,provided=req.headers.get('x-khushi-migration');if(typeof expected!=='string'||expected.length<40||provided!==expected)return new Response('Not found',{status:404});
 const id=new URL(req.url).searchParams.get('media')||'';if(!/^[a-f0-9-]{36}$/.test(id))return new Response('Not found',{status:404});const object=await bucket().get(id);if(!object)return new Response('Not found',{status:404});const headers=new Headers({'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});object.writeHttpMetadata(headers);headers.set('Content-Length',String(object.size));return new Response(object.body,{headers})}
