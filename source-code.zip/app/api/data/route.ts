import {database,identity,seed,fail} from '../../server';
export const dynamic='force-dynamic';
export async function GET(){try{
 const user=await identity(); if(user.primary) await seed(); const db=database();
 const [records,settings,hearts,editors]=await Promise.all([
 db.prepare('SELECT * FROM records ORDER BY created DESC,id').all(),db.prepare('SELECT * FROM settings').all(),
 db.prepare('SELECT record,COUNT(*) AS count,MAX(CASE WHEN user=? THEN 1 ELSE 0 END) AS mine FROM hearts GROUP BY record').bind(user.userId).all(),
 user.primary?db.prepare('SELECT email FROM editors').all():Promise.resolve({results:[]})]);
 return Response.json({user:{name:user.displayName,email:user.email,owner:user.owner,primary:user.primary},records:records.results,settings:Object.fromEntries(settings.results.map((s:any)=>[s.key,s.value])),hearts:hearts.results,editors:editors.results},{headers:{'Cache-Control':'private, no-store'}});
 }catch(e){return fail(e)}}
