import {database,identity,owner,checkWrite,clean,fail,bucket,initialPhotos} from '../../server';
import {validPlaceDate,safeMapLink,coordinates} from '../../places-model';
export const dynamic='force-dynamic';
export async function GET(){try{await identity();const rows=await database().prepare('SELECT * FROM places ORDER BY date DESC,created DESC LIMIT 300').all();return Response.json({places:rows.results},{headers:{'Cache-Control':'private, no-store'}})}catch(e){return fail(e)}}
export async function POST(req:Request){try{checkWrite(req);await owner();const d:any=await req.json();
 const title=clean(d.title,150);if(!title)return new Response('Jagah ka naam likhein.',{status:400});
 const date=clean(d.date,10);if(date&&!validPlaceDate(date))return new Response('Sahi date chunein.',{status:400});
 const mapUrl=safeMapLink(clean(d.map_url,1500));if(mapUrl===null)return new Response('Google Maps ya OpenStreetMap ka HTTPS link dein.',{status:400});
 const coords=coordinates(d.latitude,d.longitude);if(!coords)return new Response('Latitude aur longitude dono sahi bharein.',{status:400});
 const photo=clean(d.photo,300);if(photo){if(photo.startsWith('/api/media/')&&/^\/api\/media\/[a-f0-9-]{36}$/.test(photo)){const obj=await bucket().head(photo.split('/').pop()!);if(!obj?.httpMetadata?.contentType?.startsWith('image/'))return new Response('Photo file upload karein.',{status:400});}else if(!initialPhotos.some(p=>photo==='/photos/'+p[2]))return new Response('Pehle photo upload karein.',{status:400});}
 const db=database(),id=clean(d.id,60)||crypto.randomUUID(),now=Date.now();if(d.id&&!await db.prepare('SELECT id FROM places WHERE id=?').bind(id).first())return new Response('Place nahi mili. Reload karein.',{status:404});
 if(!d.id){const n=await db.prepare('SELECT COUNT(*) AS n FROM places').first<{n:number}>();if((n?.n||0)>=300)return new Response('300 places save ho gayi hain.',{status:400});}
 await db.prepare('INSERT INTO places(id,title,story,date,photo,map_url,latitude,longitude,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,story=excluded.story,date=excluded.date,photo=excluded.photo,map_url=excluded.map_url,latitude=excluded.latitude,longitude=excluded.longitude,updated=excluded.updated').bind(id,title,clean(d.story,4000),date,photo,mapUrl,coords.latitude,coords.longitude,now,now).run();return Response.json({id});
 }catch(e){return fail(e)}}
export async function DELETE(req:Request){try{checkWrite(req);await owner();const d:any=await req.json();await database().prepare('DELETE FROM places WHERE id=?').bind(clean(d.id,60)).run();return Response.json({ok:true})}catch(e){return fail(e)}}
