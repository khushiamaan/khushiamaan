import {notifyIncoming} from '../../push';
import {env} from 'cloudflare:workers';
import {database,owner,checkWrite,clean,fail} from '../../server';
type Call={id:string,caller:string,callee:string,mode:string,offer:string,answer:string,state:string,created:number,caller_seen:number,callee_seen:number};
const now=()=>Math.floor(Date.now()/1000);
const expired=(c:Call)=>c.state==='ringing'?c.created<now()-90:c.state==='accepted'&&(c.caller_seen<now()-45||c.callee_seen<now()-45);
async function current(email:string){const c=await database().prepare("SELECT * FROM calls WHERE slot='couple'").first<Call>();if(!c||![c.caller,c.callee].includes(email))return null;if(expired(c)){await database().prepare("UPDATE calls SET state='ended',offer='',answer='' WHERE slot='couple' AND id=?").bind(c.id).run();return {...c,state:'ended',offer:'',answer:''}}return c}
export const dynamic='force-dynamic';
export async function GET(){try{const u=await owner();return Response.json({call:await current(u.email.toLowerCase()),iceServers:[{urls:'stun:stun.cloudflare.com:3478'}]},{headers:{'Cache-Control':'private, no-store'}})}catch(e){return fail(e)}}
export async function POST(req:Request){try{checkWrite(req);const u=await owner(),email=u.email.toLowerCase();const d:any=await req.json();const db=database();
 if(d.action==='start'){
  const target=u.primary?(await db.prepare('SELECT email FROM editors LIMIT 1').first<{email:string}>())?.email:env.OWNER_EMAIL?.toLowerCase();
  if(!target||target===email)return new Response('Pehle partner ko Site invite aur edit permission dein.',{status:400});
  if(!['audio','video'].includes(d.mode)||typeof d.offer!=='string'||!d.offer.startsWith('v=0')||d.offer.length>60000)return new Response('Invalid call offer.',{status:400});
  const c=await db.prepare("SELECT * FROM calls WHERE slot='couple'").first<Call>();if(c&&['ringing','accepted'].includes(c.state)&&!expired(c))return new Response('Ek call pehle se chal rahi hai.',{status:409});
  const id=crypto.randomUUID(),t=now();const r=await db.prepare("INSERT INTO calls(slot,id,caller,callee,mode,offer,answer,state,created,caller_seen,callee_seen) VALUES('couple',?,?,?,?,?,'','ringing',?,?,0) ON CONFLICT(slot) DO UPDATE SET id=excluded.id,caller=excluded.caller,callee=excluded.callee,mode=excluded.mode,offer=excluded.offer,answer='',state='ringing',created=excluded.created,caller_seen=excluded.caller_seen,callee_seen=0 WHERE calls.state='ended' OR (calls.state='ringing' AND calls.created<?) OR (calls.state='accepted' AND (calls.caller_seen<? OR calls.callee_seen<?))").bind(id,email,target,d.mode,d.offer,t,t,t-90,t-45,t-45).run();
  if(!r.meta.changes)return new Response('Ek call pehle se chal rahi hai.',{status:409});const notification=await notifyIncoming(target,id,d.mode,t);return Response.json({call:await current(email),notification});
 }
 const c=await current(email);if(!c||c.id!==d.id||c.state==='ended')return new Response('Call khatam ho chuki hai.',{status:410});
 if(d.action==='answer'){
  if(email!==c.callee||c.state!=='ringing')return new Response('Is call ko accept nahi kar sakte.',{status:403});
  if(typeof d.answer!=='string'||!d.answer.startsWith('v=0')||d.answer.length>60000)return new Response('Invalid call answer.',{status:400});
  await db.prepare("UPDATE calls SET answer=?,state='accepted',callee_seen=? WHERE slot='couple' AND id=? AND state='ringing'").bind(d.answer,now(),c.id).run();
 }else if(d.action==='ping'){
  await db.prepare(email===c.caller?"UPDATE calls SET caller_seen=? WHERE slot='couple' AND id=?":"UPDATE calls SET callee_seen=? WHERE slot='couple' AND id=?").bind(now(),c.id).run();
 }else if(d.action==='end'){
  await db.prepare("UPDATE calls SET state='ended',offer='',answer='' WHERE slot='couple' AND id=?").bind(c.id).run();
 }else return new Response('Invalid call action.',{status:400});
 return Response.json({call:await current(email)});
 }catch(e){return fail(e)}}
