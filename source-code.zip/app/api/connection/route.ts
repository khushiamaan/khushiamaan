import {database,identity,owner,checkWrite,clean,fail} from '../../server';
import {questions} from '../../connection-model';
import {validPlaceDate} from '../../places-model';
export async function GET(){try{await identity();const db=database();const [events,answers,room]=await Promise.all([db.prepare("SELECT * FROM records WHERE type='event' ORDER BY date,id").all(),db.prepare("SELECT * FROM records WHERE type='answer' ORDER BY created DESC,id").all(),db.prepare("SELECT value FROM settings WHERE key='together-room'").first<{value:string}>()]);return Response.json({events:events.results,answers:answers.results,room:room?JSON.parse(room.value):null,serverTime:Date.now()},{headers:{'Cache-Control':'private, no-store'}})}catch(e){return fail(e)}}
export async function POST(req:Request){try{checkWrite(req);const u=await owner();const d:any=await req.json();const db=database(),now=Date.now();
 if(d.action==='event'){
 const title=clean(d.title,150),date=clean(d.date,10),body=JSON.stringify({text:clean(d.text,2000),yearly:!!d.yearly});if(!title||!validPlaceDate(date))return new Response('Naam aur sahi date chunein.',{status:400});
 const id=clean(d.id,60)||crypto.randomUUID();if(d.id&&!await db.prepare("SELECT id FROM records WHERE id=? AND type='event'").bind(id).first())return new Response('Event not found.',{status:404});
 await db.prepare("INSERT INTO records(id,type,title,body,date,media,mime,done,created) VALUES(?,'event',?,?,?,'','',0,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,body=excluded.body,date=excluded.date").bind(id,title,body,date,new Date(now).toISOString()).run();return Response.json({id});
 }
 if(d.action==='delete-event'){const id=clean(d.id,60);await db.prepare("DELETE FROM records WHERE id=? AND type='event'").bind(id).run();return Response.json({ok:true})}
 if(d.action==='answer'){
 const question=questions.find(q=>q[0]===d.question),text=clean(d.text,2000);if(!question||!text)return new Response('Sawal aur apna jawab chunein.',{status:400});
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(u.userId+'\0'+question[0])))).map(b=>b.toString(16).padStart(2,'0')).join('');const id='answer-'+hash;
 const body=JSON.stringify({question:question[0],text,author:u.displayName,email:u.email});
 await db.prepare("INSERT INTO records(id,type,title,body,date,media,mime,done,created) VALUES(?,'answer',?,?,'','','',0,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,created=excluded.created").bind(id,question[1],body,new Date(now).toISOString()).run();return Response.json({id});
 }
 if(d.action==='room'){
 const record=clean(d.record,60),activity=clean(d.activity,300);if(record&&!await db.prepare("SELECT id FROM records WHERE id=? AND type='memory' AND media<>''").bind(record).first())return new Response('Gallery ki memory chunein.',{status:400});
 if(typeof d.position!=='number'||!Number.isFinite(d.position)||d.position<0||d.position>86400)return new Response('Invalid playback position.',{status:400});
 const room={record,activity,position:d.position,playing:!!d.playing,updated:now};await db.prepare("INSERT INTO settings(key,value) VALUES('together-room',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(JSON.stringify(room)).run();return Response.json({room,serverTime:now});
 }
 return new Response('Invalid action.',{status:400});
 }catch(e){return fail(e)}}
