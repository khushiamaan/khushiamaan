import {bucket,owner,checkWrite,fail} from '../../server';
export async function POST(req:Request){try{checkWrite(req);await owner();if(Number(req.headers.get('content-length')||0)>51*1024*1024)return new Response('File 50 MB se chhoti rakhein.',{status:413});
 const form=await req.formData();const file=form.get('file');if(!(file instanceof File))return new Response('File chunein.',{status:400});
 if(file.size>50*1024*1024||file.size===0)return new Response('File 1 byte se 50 MB ke beech honi chahiye.',{status:413});
 const allowed=['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime','audio/mpeg','audio/mp4','audio/webm','audio/ogg','audio/wav'];
 if(!allowed.includes(file.type))return new Response('JPG, PNG, WebP, GIF, MP4, WebM ya audio file chunein.',{status:400});
 const key=crypto.randomUUID();await bucket().put(key,file.stream(),{httpMetadata:{contentType:file.type},customMetadata:{name:file.name.slice(0,150)}});
 return Response.json({media:'/api/media/'+key,mime:file.type});}catch(e){return fail(e)}}
