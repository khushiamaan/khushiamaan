import { database, owner, checkWrite, clean, fail } from '../../server';
export const dynamic = 'force-dynamic';
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// This manages application roles and an invitation checklist. Hosting invites are
// deliberately NOT asserted or sent: the platform currently has no hosted binding.
export async function GET() {
  try {
    const u = await owner();
    const [editors, requests] = await Promise.all([
      database().prepare('SELECT email FROM editors ORDER BY email').all(),
      database().prepare('SELECT email,role,created FROM access_requests ORDER BY created DESC LIMIT 100').all(),
    ]);
    return Response.json({ primary: u.primary, self: u.email.toLowerCase(), editors: editors.results,
      requests: requests.results, hostingInvitesAvailable: false }, { headers: { 'Cache-Control': 'private, no-store' } });
  } catch (e) { return fail(e); }
}
export async function POST(req: Request) {
  try {
    checkWrite(req);
    const origin = req.headers.get('origin');
    if (origin && origin !== new URL(req.url).origin) return new Response('Open this form in the app.', {status:403});
    const u = await owner();
    const d: any = await req.json();
    if (typeof d.email !== 'string' || d.email.length > 254) return new Response('Valid Gmail / email likhein.', {status:400});
    const email = clean(d.email,254).toLowerCase();
    if (!emailPattern.test(email)) return new Response('Valid Gmail / email likhein.', {status:400});
    const db = database();
    if (d.action === 'prepare') {
      if (!['guest','coadmin'].includes(d.role)) return new Response('Guest ya Co-admin chunein.', {status:400});
      // Role management stays with the original owner. A co-admin can prepare guest invitations.
      if (d.role === 'coadmin' && !u.primary) return new Response('Co-admin sirf Owner assign kar sakta hai.', {status:403});
      if (email === u.email.toLowerCase()) return new Response('Apne account ke liye invitation zaroori nahi hai.', {status:400});
      const count = await db.prepare('SELECT COUNT(*) AS n FROM access_requests WHERE email<>?').bind(email).first<{n:number}>();
      if ((count?.n || 0) >= 100) return new Response('Invitation list mein 100 entries ho gayi hain.',{status:400});
      if (d.role === 'coadmin') {
        // Atomic INSERT SELECT avoids concurrent requests creating multiple partners.
        await db.prepare('INSERT OR IGNORE INTO editors(email) SELECT ? WHERE NOT EXISTS(SELECT 1 FROM editors WHERE email<>?)').bind(email,email).run();
        if (!await db.prepare('SELECT email FROM editors WHERE email=?').bind(email).first()) return new Response('Pehle maujooda partner ka Co-admin role hatao.',{status:409});
      } else if (await db.prepare('SELECT email FROM editors WHERE email=?').bind(email).first()) {
        return new Response('Is account ka Co-admin role pehle se hai.',{status:409});
      }
      await db.prepare('INSERT INTO access_requests(email,role,created) VALUES(?,?,?) ON CONFLICT(email) DO UPDATE SET role=excluded.role').bind(email,d.role,Date.now()).run();
      return Response.json({ok:true, role:d.role, invitationSent:false, hostingAccess:'not_verified'});
    }
    if (d.action === 'remove-request') {
      const editor = await db.prepare('SELECT email FROM editors WHERE email=?').bind(email).first();
      if (editor) return new Response('Co-admin ke role ke liye alag action use karein.',{status:409});
      await db.prepare('DELETE FROM access_requests WHERE email=?').bind(email).run();
      return Response.json({ok:true,hostingAccessChanged:false});
    }
    if (d.action === 'remove-coadmin') {
      if (!u.primary) return new Response('Co-admin role sirf Owner hata sakta hai.',{status:403});
      await db.batch([db.prepare('DELETE FROM editors WHERE email=?').bind(email),db.prepare('DELETE FROM access_requests WHERE email=?').bind(email)]);
      return Response.json({ok:true,hostingAccessChanged:false});
    }
    return new Response('Invalid action.',{status:400});
  } catch (e) { return fail(e); }
}
