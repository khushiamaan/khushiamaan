import {database,owner,identity,checkWrite,clean,fail,initialPhotos,bucket} from '../../server';
export async function POST(req:Request){try{checkWrite(req);await owner();const d:any=await req.json();
 const type=clean(d.type);if(!['memory','note','milestone','wish'].includes(type))return new Response('Choose a valid type.',{status:400});
 const title=clean(d.title,150);if(!title)return new Response('Title zaroori hai.',{status:400});
 const media=clean(d.media,300);if(media&&!/^\/api\/media\/[a-f0-9-]{36}$/.test(media)&&!initialPhotos.some(p=>media==='/photos/'+p[2]))return new Response('Upload this file first.',{status:400});
 if(media.startsWith('/api/media/')&&!await bucket().head(media.split('/').pop()!))return new Response('Uploaded file missing.',{status:400});
 const id=clean(d.id,60)||crypto.randomUUID();if(d.id&&!await database().prepare('SELECT id FROM records WHERE id=?').bind(id).first())return new Response('Memory not found.',{status:404});
 const date=clean(d.date,10);if(date&&!/^\d{4}-\d{2}-\d{2}$/.test(date))return new Response('Date theek se chunein.',{status:400});
 await database().prepare('INSERT INTO records(id,type,title,body,date,media,mime,done,created) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET type=excluded.type,title=excluded.title,body=excluded.body,date=excluded.date,media=excluded.media,mime=excluded.mime,done=excluded.done').bind(id,type,title,clean(d.body),date,media,clean(d.mime,80),d.done?1:0,new Date().toISOString()).run();
 return Response.json({id});}catch(e){return fail(e)}}
export async function DELETE(req:Request){try{checkWrite(req);await owner();const d:any=await req.json();const id=clean(d.id,60);const row=await database().prepare('SELECT media FROM records WHERE id=?').bind(id).first<any>();
 await database().batch([database().prepare('DELETE FROM records WHERE id=?').bind(id),database().prepare('DELETE FROM hearts WHERE record=?').bind(id)]);
 if(row?.media?.startsWith('/api/media/')){const used=await database().prepare('SELECT id FROM records WHERE media=?').bind(row.media).first();const cover=await database().prepare("SELECT value FROM settings WHERE key IN ('cover','music') AND value=?").bind(row.media).first();const place=await database().prepare('SELECT id FROM places WHERE photo=? LIMIT 1').bind(row.media).first();if(!used&&!cover&&!place)await bucket().delete(row.media.split('/').pop());}
 return Response.json({ok:true});}catch(e){return fail(e)}}
export async function PATCH(req:Request){try{checkWrite(req);const u=await identity();const{id}=await req.json() as {id:string};if(!await database().prepare('SELECT id FROM records WHERE id=?').bind(id).first())return new Response('Not found',{status:404});
 const exists=await database().prepare('SELECT user FROM hearts WHERE record=? AND user=?').bind(id,u.userId).first();
 await database().prepare(exists?'DELETE FROM hearts WHERE record=? AND user=?':'INSERT OR IGNORE INTO hearts(record,user) VALUES(?,?)').bind(id,u.userId).run();return Response.json({ok:true});}catch(e){return fail(e)}}
