export const videoEffects=[['natural','Natural'],['soft','Soft touch-up'],['warm','Warm'],['cool','Cool'],['mono','Black & white'],['rose','Rosy']] as const;
export type VideoEffect=typeof videoEffects[number][0];
export function effectFilter(effect:VideoEffect,strength:number){const n=Math.max(0,Math.min(40,Number.isFinite(strength)?strength:20));switch(effect){case 'soft':return `blur(${(n/100).toFixed(2)}px) brightness(${(1+n/1000).toFixed(3)}) contrast(1.02)`;case 'warm':return 'sepia(0.22) saturate(1.15) brightness(1.04)';case 'cool':return 'saturate(0.88) hue-rotate(12deg) brightness(1.03)';case 'mono':return 'grayscale(1) contrast(1.06)';case 'rose':return 'sepia(0.12) saturate(1.2) hue-rotate(325deg) brightness(1.03)';default:return 'none'}}
export type EffectCapture={track:MediaStreamTrack,preview:MediaStream,set:(effect:VideoEffect,strength:number)=>void,stop:()=>void};
/** Only the existing camera enters the canvas. Audio is never copied, filtered or stopped here. */
export async function createEffectCapture(source:MediaStream,signal:AbortSignal,onFailure:()=>void):Promise<EffectCapture>{
 const camera=source.getVideoTracks()[0];if(!camera)throw Error('Video camera active nahi hai.');
 const video=document.createElement('video'),canvas=document.createElement('canvas');const ctx=canvas.getContext('2d');
 if(!ctx||!('filter'in ctx)||typeof canvas.captureStream!=='function')throw Error('Is WebView mein live filters supported nahi hain. Natural video chal rahi hai.');
 video.muted=true;video.autoplay=true;video.playsInline=true;video.srcObject=new MediaStream([camera]);video.setAttribute('aria-hidden','true');video.style.cssText='position:fixed;width:1px;height:1px;left:-10px;top:-10px;pointer-events:none';document.body.appendChild(video);
 let stopped=false,timer:ReturnType<typeof setInterval>|undefined,capture:MediaStream|undefined,effect:VideoEffect='natural',strength=20;
 const stop=()=>{if(stopped)return;stopped=true;if(timer)clearInterval(timer);capture?.getTracks().forEach(t=>t.stop());video.pause();video.srcObject=null;video.remove();canvas.width=canvas.height=1;signal.removeEventListener('abort',stop)};
 signal.addEventListener('abort',stop,{once:true});
 try{
  if(signal.aborted)throw Error('Call ended');
  await new Promise<void>((resolve,reject)=>{let settled=false;const finish=(error?:Error)=>{if(settled)return;settled=true;clearTimeout(deadline);video.removeEventListener('loadeddata',ready);signal.removeEventListener('abort',abort);error?reject(error):resolve()},ready=()=>finish(),abort=()=>finish(Error('Call ended')),deadline=setTimeout(()=>finish(Error('Video effect ready nahi hua. Natural video rakhein.')),5000);video.addEventListener('loadeddata',ready);signal.addEventListener('abort',abort,{once:true});video.play().then(()=>{if(video.readyState>=2)ready()}).catch(()=>finish(Error('Video effect playback allow nahi hui.')))});
  if(stopped||signal.aborted)throw Error('Call ended');
  const w=video.videoWidth||camera.getSettings().width||640,h=video.videoHeight||camera.getSettings().height||480,scale=Math.min(1,640/Math.max(w,h));canvas.width=Math.max(2,Math.round(w*scale));canvas.height=Math.max(2,Math.round(h*scale));
  const draw=()=>{if(stopped)return;try{if(video.videoWidth&&video.videoHeight){const scale=Math.min(1,640/Math.max(video.videoWidth,video.videoHeight)),w=Math.max(2,Math.round(video.videoWidth*scale)),h=Math.max(2,Math.round(video.videoHeight*scale));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h}}ctx.filter='none';ctx.fillStyle='#000';ctx.fillRect(0,0,canvas.width,canvas.height);if(camera.enabled&&!document.hidden&&video.readyState>=2){ctx.filter=effectFilter(effect,strength);ctx.drawImage(video,0,0,canvas.width,canvas.height);ctx.filter='none'}}catch{stop();onFailure()}};
  draw();capture=canvas.captureStream(15);const track=capture.getVideoTracks()[0];if(!track)throw Error('Live video filter unavailable.');timer=setInterval(draw,1000/15);
  return {track,preview:new MediaStream([track]),set:(value,amount)=>{effect=value;strength=amount;draw()},stop};
 }catch(e){stop();throw e}
}
/** Swaps video only; hangup during an awaited effect change must not install a late track. */
export async function replaceCallVideo(sender:{replaceTrack:(track:MediaStreamTrack)=>Promise<void>},track:MediaStreamTrack,stillCurrent:()=>boolean){if(!stillCurrent())return false;await sender.replaceTrack(track);return stillCurrent()}
