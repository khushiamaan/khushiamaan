export type Place={id:string,title:string,story:string,date:string,photo:string,map_url:string,latitude:string,longitude:string,created:number,updated:number};
export function validPlaceDate(value:string){if(!/^\d{4}-\d{2}-\d{2}$/.test(value)||value<'1900-01-01'||value>'2200-12-31')return false;const d=new Date(value+'T00:00:00Z');return Number.isFinite(d.getTime())&&d.toISOString().slice(0,10)===value}
export function safeMapLink(value:string):string|null{
 if(!value)return '';try{const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.port)return null;
 const exact=['maps.app.goo.gl','maps.google.com','www.openstreetmap.org','openstreetmap.org','osm.org'];
 const google=['google.com','www.google.com','google.co.in','www.google.co.in'].includes(u.hostname)&&/^\/maps(?:\/|$)/.test(u.pathname);
 if(!exact.includes(u.hostname)&&!google&&!(u.hostname==='goo.gl'&&u.pathname.startsWith('/maps/')))return null;return u.href;}catch{return null}
}
export function coordinates(lat:unknown,lon:unknown):{latitude:string,longitude:string}|null{
 const a=typeof lat==='string'?lat.trim():'',b=typeof lon==='string'?lon.trim():'';
 if(!a&&!b)return {latitude:'',longitude:''};if(!a||!b||!/^[-+]?\d{1,3}(?:\.\d{1,8})?$/.test(a)||!/^[-+]?\d{1,3}(?:\.\d{1,8})?$/.test(b))return null;
 const x=Number(a),y=Number(b);return Math.abs(x)<=90&&Math.abs(y)<=180?{latitude:String(x),longitude:String(y)}:null;
}
export function mapEmbed(p:Pick<Place,'latitude'|'longitude'>){if(!p.latitude||!p.longitude||!coordinates(p.latitude,p.longitude))return '';const a=Number(p.latitude),b=Number(p.longitude),delta=.012;const bbox=[Math.max(-180,b-delta),Math.max(-90,a-delta),Math.min(180,b+delta),Math.min(90,a+delta)].join(',');return 'https://www.openstreetmap.org/export/embed.html?'+new URLSearchParams({bbox,layer:'mapnik',marker:`${a},${b}`})}
