export const VOICE_LIMIT_SECONDS = 120;
export const VOICE_LIMIT_BYTES = 8 * 1024 * 1024;
export function voiceMime(Recorder: Pick<typeof MediaRecorder, 'isTypeSupported'>) {
 return ['audio/webm;codecs=opus','audio/mp4','audio/ogg;codecs=opus','audio/webm'].find(m=>Recorder.isTypeSupported(m)) || '';
}
export function voiceFile(blob:Blob) {
 const mime=blob.type.split(';')[0];
 if(!['audio/webm','audio/mp4','audio/ogg','audio/wav','audio/mpeg'].includes(mime))throw new Error('Is format ki recording supported nahi. Audio file upload karein.');
 if(!blob.size||blob.size>VOICE_LIMIT_BYTES)throw new Error('Recording khaali ya 8 MB se badi hai. Chhota message record karein.');
 return new File([blob],`voice-postcard.${mime==='audio/mp4'?'m4a':mime==='audio/ogg'?'ogg':mime==='audio/wav'?'wav':mime==='audio/mpeg'?'mp3':'webm'}`,{type:mime});
}
// Owns the microphone from construction through every stop/error/discard path.
export function captureVoice(stream:MediaStream, Recorder:typeof MediaRecorder, done:(blob:Blob|null,error?:string)=>void) {
 let rec:MediaRecorder;let chunks:BlobPart[]=[];let size=0,discarded=false,finished=false,ending=false;
 const release=()=>stream.getTracks().forEach(t=>t.stop());
 const finish=(blob:Blob|null,error?:string)=>{if(finished)return;finished=true;clearTimeout(timer);release();if(!discarded)done(blob,error)};
 let timer:ReturnType<typeof setTimeout>;
 try{const mimeType=voiceMime(Recorder);rec=new Recorder(stream,mimeType?{mimeType}:undefined)}catch(e){release();throw e}
 const stop=(discard=false)=>{discarded=discarded||discard;clearTimeout(timer);if(ending)return;ending=true;release();if(rec.state!=='inactive')rec.stop();else finish(null)};
 rec.ondataavailable=e=>{if(!finished&&e.data.size){size+=e.data.size;chunks.push(e.data);if(size>VOICE_LIMIT_BYTES){finish(null,'Recording 8 MB tak rakh sakte hain. Dobara chhota message record karein.');stop(true)}}};
 rec.onerror=()=>{finish(null,'Recording ruk gayi. Dobara try karein.');if(rec.state!=='inactive')rec.stop()};
 rec.onstop=()=>finish(discarded?null:new Blob(chunks,{type:rec.mimeType||'audio/webm'}));
 try{rec.start(250);timer=setTimeout(()=>stop(),VOICE_LIMIT_SECONDS*1000)}catch(e){release();throw e}
 return {stop};
}
