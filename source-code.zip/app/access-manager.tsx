'use client';
import {apiFetch,mediaUrl,sitePath,portable} from './client-api';
import {useEffect,useState} from 'react';
import {Users,Heart,Copy,RefreshCw,ShieldCheck,Trash2,ArrowUpRight} from 'lucide-react';
type AccessData={primary:boolean,self:string,editors:{email:string}[],requests:{email:string,role:'guest'|'coadmin',created:number}[]};
async function request(body?:unknown):Promise<any>{const r=await apiFetch('/api/access',body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{cache:'no-store'});if(!r.ok)throw new Error(await r.text());return r.json()}
export default function AccessManager({refresh,notify}:{refresh:()=>Promise<void>,notify:(s:string)=>void}){
 const [data,setData]=useState<AccessData|null>(null),[email,setEmail]=useState(''),[role,setRole]=useState<'guest'|'coadmin'>('guest'),[busy,setBusy]=useState(false),[error,setError]=useState(''),[confirm,setConfirm]=useState<{email:string,action:string}|null>(null),[manual,setManual]=useState('');
 async function load(){try{setData(await request());setError('')}catch(e:any){setError(e.message)}}
 useEffect(()=>{load()},[]);
 async function change(body:unknown){setBusy(true);setError('');try{await request(body);await load();await refresh();return true}catch(e:any){setError(e.message);return false}finally{setBusy(false)}}
 async function copy(target:string,remove=false){const text=remove?`Amaan ki Khushi Site https://amaan-ki-khushi.honestghost8.chatgpt.site (project appgprj_6ae20d46fa4081918b957f6629c13310) se ${target} ka visitor access hatao. Baaki users aur invite-only setting same rakho.`:`Amaan ki Khushi Site https://amaan-ki-khushi.honestghost8.chatgpt.site (project appgprj_6ae20d46fa4081918b957f6629c13310) par ${target} ko visitor invite/access do. Baaki users aur invite-only setting same rakho. App ka Guest/Co-admin role alag se save kiya gaya hai; hosting project editor permission mat badlo.`;
 try{await navigator.clipboard.writeText(text);notify('Request copy hui. ChatGPT mein paste karke bhejein.')}catch{setManual(text)}}
 const editors=data?.editors||[];const guests=(data?.requests||[]).filter(r=>r.role==='guest'&&!editors.some(e=>e.email===r.email));
 return <div className="settings-card access-manager"><Users/><div className="eyebrow">OUR PEOPLE, OUR LITTLE WORLD</div><h2>Apno ka access ♡</h2><p>Tum Owner. Tumhari partner Co-admin. Apne khaas log Guest.</p>
 <div className="access-roles"><div><ShieldCheck size={19}/><strong>Owner</strong><small>Co-admin role, yaadein aur guest checklist sambhalo.</small></div><div><Heart size={19}/><strong>Co-admin</strong><small>Photos, notes, music, editing, calls aur guest checklist.</small></div><div><Users size={19}/><strong>Guest</strong><small>Published yaadein dekho aur hearts bhejo. Editing aur calls nahi.</small></div></div>
 <p className="access-note"><strong>Site invitation ka ek step baaki rahega.</strong> Yahan role / invitation checklist save hoti hai. Email invite bhejna aur Site mein entry dena abhi ChatGPT ki Site Share settings se hota hai. App ise automatically verify nahi kar sakta.</p>
 {error&&<p className="form-error" role="alert">{error}</p>}
 {!data?<button className="outline" onClick={load}><RefreshCw size={16}/> Reload access</button>:<>
 <div className="access-status"><ShieldCheck size={16}/> Tumhara role: {data.primary?'Owner':'Co-admin'}</div>
 <form onSubmit={async e=>{e.preventDefault();const target=email.trim().toLowerCase();if(await change({action:'prepare',email:target,role})){setEmail('');notify(role==='coadmin'?'Co-admin role save hua. Site invitation alag se complete karein.':'Guest checklist save hui. Invitation abhi nahi bheja gaya.')}}}>
 <label>Gmail / email<input type="email" autoComplete="email" required maxLength={254} value={email} onChange={e=>setEmail(e.target.value)} placeholder="someone@gmail.com" disabled={busy}/></label>
 <label>Role<select value={role} disabled={busy} onChange={e=>setRole(e.target.value as 'guest'|'coadmin')}><option value="guest">Guest · view & react</option>{data.primary&&<option value="coadmin">Co-admin · upload, edit & calls</option>}</select></label>
 <button className="primary" disabled={busy} type="submit">{busy?'Save ho raha hai…':role==='coadmin'?'Co-admin role save karo':'Guest invite checklist mein jodo'}</button>
 </form>
 <h3>Co-admin {editors.length?`(${editors.length})`:''}</h3><p className="hint">Abhi test account bhi yahan ho sakta hai. GF ki Gmail milne par Owner use replace kar sakta hai. Ek waqt mein ek partner.</p>
 {!editors.length&&<p className="hint">Abhi Co-admin assign nahi hai.</p>}
 {editors.map(e=><div className="access-person" key={e.email}><strong>{e.email}</strong><span>Co-admin role saved · Site invite status unverified</span><div><button className="outline" disabled={busy} onClick={()=>copy(e.email)}><Copy size={15}/> Invite request copy</button>{data.primary&&<button className="text-link" disabled={busy} onClick={()=>setConfirm({email:e.email,action:'remove-coadmin'})}>Co-admin role hatao</button>}</div></div>)}
 <h3>Guest invitation checklist</h3><p className="hint">Yeh complete Site visitor list nahi hai. Saved entries invitation sent/accepted hone ka proof nahi hain.</p>
 {!guests.length&&<p className="hint">Gmail daalkar apne pehle Guest ki checklist taiyar karo.</p>}
 {guests.map(g=><div className="access-person" key={g.email}><strong>{g.email}</strong><span>Guest · Site invitation not verified</span><div><button className="outline" disabled={busy} onClick={()=>copy(g.email)}><Copy size={15}/> Invite request copy</button><button className="text-link" disabled={busy} onClick={()=>copy(g.email,true)}>Site access hatane ki request</button><button className="icon-btn" aria-label={'Remove checklist entry '+g.email} disabled={busy} onClick={()=>setConfirm({email:g.email,action:'remove-request'})}><Trash2 size={16}/></button></div></div>)}
 <div className="access-next"><strong>Invitation complete kaise karein</strong><p>Invite request copy karke apne Owner wale ChatGPT account mein bhejo, ya is Site ki Share settings mein email add karo. Guest bhi usi email se ChatGPT sign in karega.</p><a className="outline" href="https://chatgpt.com/" target="_blank" rel="noopener noreferrer">ChatGPT kholo <ArrowUpRight size={16}/></a></div>
 {confirm&&<div className="access-note" role="group" aria-label="Confirm role or checklist removal"><strong>{confirm.email}</strong><p>{confirm.action==='remove-coadmin'?'Iska upload/edit/call role hat jayega. Site viewer access Share settings se alag hatana hoga.':'Sirf checklist entry hategi. Isse Site viewer access revoke nahi hota.'}</p><button className="outline" disabled={busy} onClick={()=>setConfirm(null)}>Cancel</button> <button className="primary" disabled={busy} onClick={async()=>{if(await change(confirm)){setConfirm(null);notify('Update save hua. Site access alag se manage hota hai.')}}}>Remove</button></div>}
 </>}
 {manual&&<label>Yeh request ChatGPT mein bhejein<textarea rows={6} readOnly value={manual}/></label>}
 <p className="hint">Sab invited guests wahi published photos aur notes dekhte hain. Co-admin app ka role hai; hosting, billing aur original Owner account ka control transfer nahi hota.</p>
 </div>
}
