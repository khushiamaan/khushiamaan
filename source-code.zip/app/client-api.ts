// Default hosted transport. The standalone GitHub build aliases this module.
export const portable=false;
export function mediaUrl(path:string){return path}
export function sitePath(path:string){return path}
export function apiFetch(input:RequestInfo|URL,init?:RequestInit){return fetch(input,init)}

export async function callCredentials():Promise<{accessToken?:string,refreshToken?:string,expiresAt?:number}>{return {}}
