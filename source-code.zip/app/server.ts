import { env } from 'cloudflare:workers';
import { getChatGPTUser } from './chatgpt-auth';
// Runtime owner configuration; ownership is never assigned to the first visitor.
const ownerEmail = () => ((env as Cloudflare.Env & { OWNER_EMAIL?: string }).OWNER_EMAIL || '').toLowerCase();
export const initialPhotos = [
  ['saath','Saath, hamesha','259145.png'], ['khushi','Tumhari muskurahat','280418.jpg'],
  ['duniya','Hamari duniya','259146.png'], ['rose','A little rose magic','267813.jpg'],
  ['moon','Chaand si roshni','263850.jpg'], ['amaan','Amaan ke rang','269590.png'],
  ['lamha','Ek khoobsurat lamha','264087.jpg'], ['sukoon','Mera sukoon','267425.jpg'],
  ['muskaan','Bas ek muskaan','259139.jpg'], ['classic','Classic memories','267772.png'],
  ['everyday','Everyday moments','278668.jpg'], ['soft','Soft little moments','280585.jpg'],
  ['portrait','Amaan','263505.jpg'],
];
export function database() { if(!env.DB) throw new Error('Memory storage is not connected.'); return env.DB; }
export function bucket() { if(!env.BUCKET) throw new Error('Photo storage is not connected.'); return env.BUCKET; }
export async function identity() {
  const user = await getChatGPTUser();
  if(!user) throw new Response('Sign in to continue.', {status:401});
  const primary = user.email.toLowerCase() === ownerEmail();
  const editor = primary || !!(await database().prepare('SELECT email FROM editors WHERE email=?').bind(user.email.toLowerCase()).first());
  return {...user, owner:editor, primary};
}
export async function owner() { const u=await identity(); if(!u.owner) throw new Response('Only Amaan and Khushi can make changes.',{status:403}); return u; }
export function checkWrite(req:Request) { if(req.headers.get('sec-fetch-site')==='cross-site') throw new Response('Please open the app to make changes.',{status:403}); }
export const clean = (s:unknown,n=4000) => typeof s==='string'?s.trim().slice(0,n):'';
export function fail(e:unknown) { if(e instanceof Response) return e; console.error(e); return Response.json({error:'Abhi save nahi hua. Please dobara try karein.'},{status:500}); }
export async function seed() {
  const db=database(); if(await db.prepare("SELECT value FROM settings WHERE key='seeded'").first()) return;
  await db.batch([...initialPhotos.map(([id,title,file],index)=>db.prepare("INSERT OR IGNORE INTO records(id,type,title,body,date,media,mime,done,created) VALUES(?, 'memory', ?, '', '', ?, ?,0,?)").bind(id,title,'/photos/'+file,file.endsWith('.png')?'image/png':'image/jpeg',new Date(Date.UTC(2026,9,28)-index*1000).toISOString())),
    db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES('seeded','yes')")]);
}
