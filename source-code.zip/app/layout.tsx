import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Amaan ki Khushi • Har khushi, tumse.',description:'Hamari kahani. Hamari yaadein. Hamara jahaan.',manifest:'/manifest.webmanifest',icons:{icon:'/icon.svg',apple:'/icon-192.png'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="hi-Latn"><head><meta name="theme-color" content="#230e19"/><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/></head><body>{children}</body></html>}
