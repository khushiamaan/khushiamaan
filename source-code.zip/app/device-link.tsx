'use client';
import {apiFetch,mediaUrl,sitePath,portable} from './client-api';
import {useEffect,useState} from 'react';
import {Bell,Check,X,LoaderCircle} from 'lucide-react';
export default function DeviceLink({owner}:{owner:boolean}){
 const [token,setToken]=useState(''),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
 useEffect(()=>{const h=new URLSearchParams(window.location.hash.slice(1));const t=h.get('kf-device');if(t){setToken(t);window.history.replaceState(null,'',window.location.pathname+window.location.search)}},[]);
 if(!token&&!message)return null;
 return <div className="modal-backdrop"><section className="modal" role="dialog" aria-modal="true" aria-label="Link notification phone"><div className="modal-heading"><span>{message?'Phone link status':'Is phone ko link karein?'}</span><button className="icon-btn" onClick={()=>{setToken('');setMessage('')}} aria-label="Close"><X/></button></div><Bell color="#f6aba3"/><p style={{margin:'15px 0'}}>Khushi Forever APK ki incoming-call notifications is account ke phone par aayengi. Phone par notification permission allow honi chahiye.</p>{!token?null:!owner?<p>Apne owner account se sign in karein. Phir APK mein wapas jaakar “Is phone ko notifications se link karo” dabayein.</p>:<button className="primary" disabled={busy} onClick={async()=>{setBusy(true);try{const r=await apiFetch('/api/devices',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,nickname:'Khushi Forever Android'})});if(!r.ok)throw new Error(await r.text());const d:any=await r.json();setMessage(d.pushConfigured?'Phone linked ♡ Notification delivery ka test ab phone par karna hai.':'Phone linked ♡ Firebase server permission ka setup abhi baaki hai.');setToken('')}catch(e:any){setMessage(e.message)}finally{setBusy(false)}}}>{busy?<LoaderCircle size={17}/>:<Check size={17}/>} Link this phone</button>}{message&&<p className="hint" role="status">{message}</p>}</section></div>
}
