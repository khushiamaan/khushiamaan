import {validPlaceDate} from './places-model';
export const questions=[
 ['little-joy','Aaj ki kaunsi chhoti si baat ne tumhe khush kiya?'],['first-memory','Hamari pehli baat ki sabse pyaari yaad kya hai?'],['thank-you','Aaj tum mujhe kis baat ke liye thank you kehna chahoge?'],['dream-date','Hamari next date kaisi honi chahiye?'],['comfort','Thake hue din mein main tumhara saath kaise doon?'],['song','Kaunsa gaana tumhe hamari yaad dilata hai?'],['dream-trip','Ek saath kis jagah ghoomna chahoge?'],['kindness','Meri kaunsi aadat tumhe sabse pyaari lagti hai?'],['small-promise','Is hafte ek chhota sa promise kya ho sakta hai?'],['new-hobby','Hum dono saath kaunsi nayi cheez seekh sakte hain?'],['ideal-evening','Tumhari perfect shaam kaisi hoti hai?'],['care','Tumhe pyaar aur care sabse zyada kab mehsoos hota hai?'],['funny-memory','Hamari kaunsi baat par abhi bhi hansi aati hai?'],['future','Agle saal ka ek shared dream kya hai?'],['gratitude','Aaj zindagi ki kis cheez ke liye grateful ho?'],['surprise','Ek simple surprise jo tumhe pasand aayega?'],['listen','Aaj tum kya share karna chahoge, bina kisi judgement ke?'],['tradition','Hamari apni ek chhoti tradition kya ho sakti hai?'],['food-date','Saath mein kya banana ya khana chahoge?'],['week-plan','Is hafte ek doosre ke liye kaunsa waqt nikaalein?']
] as const;
export function indiaToday(now=new Date()){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(now)}
export function daysBetween(a:string,b:string){return Math.round((Date.parse(b+'T00:00:00Z')-Date.parse(a+'T00:00:00Z'))/86400000)}
export function nextEvent(date:string,yearly:boolean,today=indiaToday()){
 if(!validPlaceDate(date)||!validPlaceDate(today))return '';
 if(!yearly)return date;
 const start=Math.max(+today.slice(0,4),+date.slice(0,4));
 for(let y=start;y<=Math.min(2200,start+8);y++){const d=y+date.slice(4);if(d>=today&&validPlaceDate(d))return d}return '';
}
export function roomPosition(position:number,playing:boolean,updated:number,now:number){return Math.max(0,position+(playing?Math.max(0,now-updated)/1000:0))}
export function safePhotos<T extends {id:string,media:string,mime:string}>(items:T[],ids:string[]){return ids.slice(0,12).map(id=>items.find(i=>i.id===id&&i.mime.startsWith('image/')&&/^\/(photos\/[^?#]+|api\/media\/[a-f0-9-]{36})$/.test(i.media))).filter((i):i is T=>!!i).filter((i,n,a)=>a.findIndex(x=>x.id===i.id)===n)}
