/** Keep voice playback mounted independently of the video/panel lifecycle. */
export function attachCallPlayback(stream:MediaStream,audio:HTMLAudioElement|null,video:HTMLVideoElement|null,onBlocked:()=>void){
 if(audio){const tracks=stream.getAudioTracks();const existing=audio.srcObject as MediaStream|null;if(!existing||existing.getAudioTracks().map(t=>t.id).join()!==tracks.map(t=>t.id).join())audio.srcObject=new MediaStream(tracks);audio.play().catch(onBlocked);}
 if(video){video.muted=true;video.srcObject=stream;video.play().catch(()=>{});}
}
