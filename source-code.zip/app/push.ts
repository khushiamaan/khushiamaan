import {env} from 'cloudflare:workers';
import {database} from './server';
type Account={project_id:string,client_email:string,private_key:string};
let cached:{value:string,expires:number}|null=null;
const enc=new TextEncoder();
function b64(bytes:Uint8Array){return btoa(Array.from(bytes,b=>String.fromCharCode(b)).join('')).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_')}
function account():Account|null{const value=(env as Cloudflare.Env).FIREBASE_SERVICE_ACCOUNT_JSON;if(!value)return null;const a=JSON.parse(value);if(a.project_id!=='khushi-forever-2cbbe'||!a.client_email||!a.private_key)throw new Error('Firebase project configuration does not match.');return a}
export function pushConfigured(){try{return !!account()}catch{return false}}
async function accessToken(a:Account){
 const now=Math.floor(Date.now()/1000);if(cached&&cached.expires>now+120)return cached.value;
 const head=b64(enc.encode(JSON.stringify({alg:'RS256',typ:'JWT'}))),body=b64(enc.encode(JSON.stringify({iss:a.client_email,scope:'https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600})));
 const pem=a.private_key.replace(/-----[^-]+-----/g,'').replace(/\s/g,'');const bytes=Uint8Array.from(atob(pem),c=>c.charCodeAt(0));
 const key=await crypto.subtle.importKey('pkcs8',bytes,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
 const signature=await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,enc.encode(head+'.'+body));
 const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion:head+'.'+body+'.'+b64(new Uint8Array(signature))}),signal:AbortSignal.timeout(10000)});
 if(!r.ok)throw new Error('Firebase server authentication failed.');const token:any=await r.json();if(!token.access_token)throw new Error('Firebase access token missing.');cached={value:token.access_token,expires:now+Math.min(Number(token.expires_in)||3600,3600)};return cached.value;
}
export async function notifyIncoming(email:string,id:string,mode:string,created:number){
 if(!pushConfigured())return {status:'not_configured',sent:0};
 const devices=await database().prepare('SELECT id,token FROM devices WHERE email=? ORDER BY created DESC LIMIT 5').bind(email).all<{id:string,token:string}>();
 if(!devices.results.length)return {status:'no_linked_phone',sent:0};
 try{const a=account()!,auth=await accessToken(a);let sent=0;
 await Promise.all(devices.results.map(async d=>{
  const r=await fetch('https://fcm.googleapis.com/v1/projects/'+a.project_id+'/messages:send',{method:'POST',headers:{Authorization:'Bearer '+auth,'Content-Type':'application/json'},body:JSON.stringify({message:{token:d.token,data:{kind:'incoming_call',call_id:id,mode,created:String(created)},android:{priority:'high',ttl:'60s',collapse_key:'khushi-incoming-call'}}}),signal:AbortSignal.timeout(10000)});
  if(r.ok){sent++;return}const error:any=await r.json().catch(()=>({}));if(error.error?.details?.some((x:any)=>x.errorCode==='UNREGISTERED'))await database().prepare('DELETE FROM devices WHERE id=?').bind(d.id).run();
 }));return {status:sent?'sent':'delivery_failed',sent};
 }catch(error){console.error('Incoming-call notification could not be sent ('+(error instanceof Error?error.name:'unknown')+').');return {status:'delivery_failed',sent:0}}
}
